package com.ekart.facp.dashboard;

import com.ekart.facp.dashboard.daos.models.Record;

import java.util.Map;

/**
 * Created by avinash.r on 07/06/16.
 */
public final class DashboardTestUtils {

    private DashboardTestUtils() {
    }

    public static String generateId(String type, String id) {

        return String.join(":", type, id);
    }

    public static Record createRecord(Map<String, Object> data, String id) {
        Record record = new Record();
        record.setData(data);
        record.setId(id);
        return record;
    }

}
