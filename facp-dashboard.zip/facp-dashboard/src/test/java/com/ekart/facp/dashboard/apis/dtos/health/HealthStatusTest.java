package com.ekart.facp.dashboard.apis.dtos.health;

import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * @author vijay.daniel
 */
public class HealthStatusTest {

    @Test
    public void shouldReturnHealthIfCheckSucceeded() {

        assertThat(HealthStatus.fromCheck(true), is(HealthStatus.HEALTHY));
    }

    @Test
    public void shouldReturnUnhealthyIfCheckFailed() {

        assertThat(HealthStatus.fromCheck(false), is(HealthStatus.UNHEALTHY));
    }
}
