package com.ekart.facp.dashboard.apis.controller;

import com.ekart.facp.dashboard.apis.BaseIntegrationTest;
import com.ekart.facp.dashboard.apis.dtos.*;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ekart.facp.dashboard.apis.DashboardTestUtils.*;
import static com.ekart.facp.dashboard.apis.TestUtils.assertDocumentSize;
import static com.ekart.facp.dashboard.apis.TestUtils.assertResponse;
import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.MAX_GROUP_BY_FIELDS;
import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.MAX_PAGE_SIZE;
import static com.ekart.facp.dashboard.apis.util.ErrorCode.VALIDATION_ERROR;
import static com.ekart.facp.dashboard.service.utility.Constants.FROM_CREATED_AT;
import static com.ekart.facp.dashboard.service.utility.Constants.PAGE;
import static com.ekart.facp.dashboard.service.utility.Constants.TO_CREATED_AT;
import static com.ekart.facp.dashboard.service.utility.ErrorCode.INDEX_NOT_FOUND;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by avinash.r on 16/05/16.
 */
public class DashboardSearchControllerIntegrationTest extends BaseIntegrationTest {

    private String nestedDocumentId;
    private String attributeValue;
    private String newAttributeValue;
    private long currentTime;
    private List<DocumentRequest> documentRequests;
    private List<DocumentRequest> nestedDocumentRequests;

    @Before
    public void setUp() {

        nestedDocumentId = randomAlphabetic(20);
        attributeValue = randomAlphabetic(20);
        newAttributeValue = randomAlphabetic(20);
        currentTime = System.currentTimeMillis();
        indexDocuments();
        indexNestedDocument(newAttributeValue, nestedDocumentId);
    }

    @Test
    public void shouldReturn400IfIndexNotFoundWhileSearching() {

        ResponseEntity<ErrorMessage> actualSearchResponse = API.searchDocuments("unknown_index", TYPE,
                ImmutableMap.of(), ErrorMessage.class);
        assertBadRequest(actualSearchResponse, INDEX_NOT_FOUND.name(), "No index found with : unknown_index");
    }

    @Test
    public void shouldReturnEmptyResponseIfTypeNotFoundWhileSearching() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, "unknown_type",
                ImmutableMap.of(), DocumentSearchResponse.class);
        assertEmptySearchResponse(actualSearchResponse);
    }

    @Test
    public void shouldReturnEmptyResponseWithSearchParamsWhenNoCriteriaMet() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                ImmutableMap.of(ATTRIBUTE_KEY, randomAlphabetic(20)), DocumentSearchResponse.class);
        assertEmptySearchResponse(actualSearchResponse);
    }

    @Test
    public void shouldReturnEmptyResponseWhenNoCriteriaMetWithNestedDocumentWhileSearching()
            throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                ImmutableMap.of(NESTED_KEY, randomAlphabetic(20)), DocumentSearchResponse.class);
        assertEmptySearchResponse(actualSearchResponse);
    }

    @Test
    public void shouldSearchDocumentsWithSearchParams() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentSearchResponse expectedSearchResponse = getExpectedSearchResponse(documentRequests);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                ImmutableMap.of(ATTRIBUTE_KEY, attributeValue), DocumentSearchResponse.class);
        assertResponse(actualSearchResponse, HttpStatus.OK, expectedSearchResponse);
    }

    @Test
    public void shouldSearchDocumentsWithSearchParamsAndHasNestedDocument() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentSearchResponse expectedSearchResponse = getExpectedSearchResponse(nestedDocumentRequests);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                ImmutableMap.of(NESTED_KEY, attributeValue), DocumentSearchResponse.class);
        assertResponse(actualSearchResponse, HttpStatus.OK, expectedSearchResponse);
    }

    @Test
    public void shouldGetOnlyConfiguredNumberOfRecordsWithSearchParamsWithoutPassingCurrentPage()
            throws InterruptedException {

        String randomValue = indexDocuments(MAX_PAGE_SIZE + 3);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                ImmutableMap.of(ATTRIBUTE_KEY, randomValue), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, MAX_PAGE_SIZE, MAX_PAGE_SIZE + 3);
    }

    @Test
    public void shouldGetOnlyConfiguredNumberOfRecordsWithSearchParamsWithPassingSecondPage()
            throws InterruptedException {

        String randomValue = indexDocuments(MAX_PAGE_SIZE + 3);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                ImmutableMap.of(ATTRIBUTE_KEY, randomValue, PAGE, 2), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, 3, MAX_PAGE_SIZE + 3);
    }

    @Test
    public void shouldGetEmptyRecordsWithSearchParamsWhenPageIsNotPresent() throws InterruptedException {

        String randomValue = indexDocuments(MAX_PAGE_SIZE + 3);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                ImmutableMap.of(ATTRIBUTE_KEY, randomValue, PAGE, 3), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, 0, MAX_PAGE_SIZE + 3);
    }

    @Test
    public void shouldGetRecordsWithSearchParamsUsingPage() throws InterruptedException {

        String randomValue = indexDocuments(2 * MAX_PAGE_SIZE + 3);
        List<Map<String, Object>> actualFieldMapPairs = Lists.newArrayList();
        List<Map<String, Object>> expectedFieldMapPairs = getExpectedSearchResponse(documentRequests).getResponse();
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);

        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                ImmutableMap.of(ATTRIBUTE_KEY, randomValue, PAGE, 1), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, MAX_PAGE_SIZE, 2 * MAX_PAGE_SIZE + 3);
        actualFieldMapPairs.addAll(actualSearchResponse.getBody().getResponse());

        actualSearchResponse = API.searchDocuments(NAME, TYPE, ImmutableMap.of(ATTRIBUTE_KEY, randomValue, PAGE, 2),
                DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, MAX_PAGE_SIZE, 2 * MAX_PAGE_SIZE + 3);
        actualFieldMapPairs.addAll(actualSearchResponse.getBody().getResponse());

        actualSearchResponse = API.searchDocuments(NAME, TYPE, ImmutableMap.of(ATTRIBUTE_KEY, randomValue, PAGE, 3),
                DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, 3, 2 * MAX_PAGE_SIZE + 3);
        actualFieldMapPairs.addAll(actualSearchResponse.getBody().getResponse());

        assertReflectionEquals(actualFieldMapPairs, expectedFieldMapPairs);
    }

    @Test
    public void shouldReturn400IfIndexNotFoundWhileSearchingWithRange() {

        ResponseEntity<ErrorMessage> actualSearchResponse = API.searchDocumentsWithRange("unknown_index", TYPE,
                ImmutableMap.of(FROM_CREATED_AT, currentTime, TO_CREATED_AT, currentTime), ErrorMessage.class);
        assertBadRequest(actualSearchResponse, INDEX_NOT_FOUND.name(), "No index found with : unknown_index");
    }

    @Test
    public void shouldReturnEmptyResponseIfTypeNotFoundWhileSearchingWithRange() {

        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(
                NAME, "unknown_type", ImmutableMap.of(FROM_CREATED_AT, currentTime, TO_CREATED_AT, currentTime),
                DocumentSearchResponse.class);
        assertEmptySearchResponse(actualSearchResponse);
    }

    @Test
    public void shouldReturn400IfFromCreatedAtIsNotPresentWhileSearchingWithRange() {

        ResponseEntity<ErrorMessage> actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE,
                ImmutableMap.of(), ErrorMessage.class);
        assertBadRequest(actualSearchResponse, VALIDATION_ERROR.name(),
                "Required Long parameter 'fromCreatedAt' is not present");
    }

    @Test
    public void shouldReturn400IfToCreatedAtIsNotPresentWhileSearchingWithRange() {

        ResponseEntity<ErrorMessage> actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE,
                ImmutableMap.of(FROM_CREATED_AT, currentTime), ErrorMessage.class);
        assertBadRequest(actualSearchResponse);
    }

    @Test
    public void shouldReturnEmptyResponseWhenNoCriteriaMetWhileSearchingWithRange() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE,
                createSearchRequest(ATTRIBUTE_KEY, randomAlphabetic(20)), DocumentSearchResponse.class);
        assertEmptySearchResponse(actualSearchResponse);
    }

    @Test
    public void shouldReturnEmptyResponseWhenNoCriteriaMetWhileSearchingWithRangeAndNestedDocument()
            throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE,
                createSearchRequest(NESTED_KEY, randomAlphabetic(20)), DocumentSearchResponse.class);
        assertEmptySearchResponse(actualSearchResponse);
    }

    @Test
    public void shouldSearchDocumentsWithSearchParamsWithRange() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentSearchResponse expectedSearchResponse = getExpectedSearchResponse(documentRequests);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                createSearchRequest(ATTRIBUTE_KEY, attributeValue), DocumentSearchResponse.class);
        assertResponse(actualSearchResponse, HttpStatus.OK, expectedSearchResponse);
    }

    @Test
    public void shouldSearchDocumentsWithSearchParamsWithRangeAndHasNestedObjects() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentSearchResponse expectedSearchResponse = getExpectedSearchResponse(nestedDocumentRequests);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocuments(NAME, TYPE,
                createSearchRequest(NESTED_KEY, attributeValue), DocumentSearchResponse.class);
        assertResponse(actualSearchResponse, HttpStatus.OK, expectedSearchResponse);
    }

    @Test
    public void shouldGetOnlyConfiguredNumberOfRecordsWithSearchParamsWithoutPassingCurrentPageWithRange()
            throws InterruptedException {

        String randomValue = indexDocuments(MAX_PAGE_SIZE + 3);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE,
                createSearchRequest(ATTRIBUTE_KEY, randomValue), DocumentSearchResponse.class);
        assertThat(actualSearchResponse.getBody().getResponse().size(), is(MAX_PAGE_SIZE));
    }

    @Test
    public void shouldGetOnlyConfiguredNumberOfRecordsWithSearchParamsWithPassingSecondPageWithRange()
            throws InterruptedException {

        String randomValue = indexDocuments(MAX_PAGE_SIZE + 3);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE,
                createSearchRequestWithPage(ATTRIBUTE_KEY, randomValue, 2), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, 3, MAX_PAGE_SIZE + 3);
    }

    @Test
    public void shouldGetEmptyRecordsWithSearchParamsWhenPageIsNotPresentWithRange() throws InterruptedException {

        String randomValue = indexDocuments(MAX_PAGE_SIZE + 3);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE,
                createSearchRequestWithPage(ATTRIBUTE_KEY, randomValue, 3), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, 0, MAX_PAGE_SIZE + 3);
    }

    @Test
    public void shouldGetRecordsWithSearchParamsUsingPageWithRange() throws InterruptedException {

        String randomValue = indexDocuments(2 * MAX_PAGE_SIZE + 3);
        List<Map<String, Object>> actualFieldMapPairs = Lists.newArrayList();
        List<Map<String, Object>> expectedFieldMapPairs = getExpectedSearchResponse(documentRequests).getResponse();
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);

        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE,
                createSearchRequestWithPage(ATTRIBUTE_KEY, randomValue, 1), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, MAX_PAGE_SIZE, 2 * MAX_PAGE_SIZE + 3);
        actualFieldMapPairs.addAll(actualSearchResponse.getBody().getResponse());

        actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE, createSearchRequestWithPage(
                ATTRIBUTE_KEY, randomValue, 2), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, MAX_PAGE_SIZE, 2 * MAX_PAGE_SIZE + 3);
        actualFieldMapPairs.addAll(actualSearchResponse.getBody().getResponse());

        actualSearchResponse = API.searchDocumentsWithRange(NAME, TYPE, createSearchRequestWithPage(
                ATTRIBUTE_KEY, randomValue, 3), DocumentSearchResponse.class);
        assertDocumentSize(actualSearchResponse, 3, 2 * MAX_PAGE_SIZE + 3);
        actualFieldMapPairs.addAll(actualSearchResponse.getBody().getResponse());

        assertReflectionEquals(actualFieldMapPairs, expectedFieldMapPairs);
    }

    @Test
    public void shouldReturn400IfNeitherQueryParamsNorRangeParamsArePresent() {

        ResponseEntity<ErrorMessage> response = API.countDocuments(
                NAME, TYPE, prepareCountRequest(null, null, ImmutableMap.of()), ErrorMessage.class);
        assertBadRequest(response, VALIDATION_ERROR.name(),
                "[AssertTrue.documentAggregationRequest.rangeParamsOrQueryParamsPresent: "
                        + "Query Parameters field cannot be null or empty.]");
    }

    @Test
    public void shouldReturn400IfGroupByFieldAreMoreThanConfiguredWhileCounting() {

        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));
        request.setGroupByFields(Lists.newArrayList("s1", "s2", "s3", "s4", "s5", "s6"));
        ResponseEntity<ErrorMessage> response = API.countDocuments(NAME, TYPE, request, ErrorMessage.class);
        assertBadRequest(response, VALIDATION_ERROR.name(),
                "[Size.documentAggregationRequest.groupByFields: groupByFields size is greater than "
                        + MAX_GROUP_BY_FIELDS + "]");
    }

    @Test
    public void shouldReturn400IfOnlyFromCreatedAtIsPresentWhileCounting() {

        DocumentAggregationRequest request = prepareCountRequest(
                currentTime, null, ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));
        ResponseEntity<ErrorMessage> response = API.countDocuments(NAME, TYPE, request, ErrorMessage.class);
        assertBadRequest(response, VALIDATION_ERROR.name(),
                "[AssertTrue.documentAggregationRequest.bothFromCreatedAtAndToCreatedAtOrNone"
                        + "Present: both fromCreatedAt and ToCreatedAt or none should be present]");
    }

    @Test
    public void shouldReturn400IfOnlyToCreatedAtIsPresentWhileCounting() {

        DocumentAggregationRequest request = prepareCountRequest(
                null, currentTime, ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));
        ResponseEntity<ErrorMessage> response = API.countDocuments(NAME, TYPE, request, ErrorMessage.class);
        assertBadRequest(response, VALIDATION_ERROR.name(),
                "[AssertTrue.documentAggregationRequest.bothFromCreatedAtAndToCreatedAtOrNone"
                        + "Present: both fromCreatedAt and ToCreatedAt or none should be present]");
    }

    @Test
    public void shouldReturn400IfGroupByFieldIsPresentButEmptyWhileCounting() {

        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));
        request.getGroupByFields().remove(0);
        ResponseEntity<ErrorMessage> response = API.countDocuments(NAME, TYPE, request, ErrorMessage.class);
        assertBadRequest(response, VALIDATION_ERROR.name(),
                "[NotEmpty.documentAggregationRequest.groupByFields: groupByFields array cannot be empty]");
    }

    @Test
    public void shouldReturn400IfOneOfGroupByFieldIsEmptyWhileCounting() {

        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));
        request.getGroupByFields().add("");
        ResponseEntity<ErrorMessage> response = API.countDocuments("unknown_index", TYPE, request, ErrorMessage.class);
        assertBadRequest(response, VALIDATION_ERROR.name(),
                "[AssertTrue.documentAggregationRequest.groupByFieldNotHavingAnyEmptyField: "
                        + "document.groupByFields.field.notEmpty]");
    }

    @Test
    public void shouldReturn400IfIndexNotFoundWhileCounting() {

        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));
        ResponseEntity<ErrorMessage> response = API.countDocuments("unknown_index", TYPE, request, ErrorMessage.class);
        assertBadRequest(response, INDEX_NOT_FOUND.name(), "No index found with : unknown_index");
    }

    @Test
    public void shouldReturnEmptyResponseIfTypeNotFoundWhileCounting() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));
        ResponseEntity<DocumentAggregatedResponse> response = API.countDocuments(
                NAME, "unknown_type", request, DocumentAggregatedResponse.class);
        assertEmptyCountResponse(response);
    }

    @Test
    public void shouldReturnEmptyResponseWithCountParamsWhenNoCriteriaMet() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(ATTRIBUTE_KEY, randomAlphabetic(20)));
        ResponseEntity<DocumentAggregatedResponse> response = API.countDocuments(
                NAME, TYPE, request, DocumentAggregatedResponse.class);
        assertEmptyCountResponse(response);
    }

    @Test
    public void shouldReturnEmptyResponseIfGroupByFieldIsNotPresentInDocument() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));
        request.getGroupByFields().add("extraGroupByField");
        ResponseEntity<DocumentAggregatedResponse> response = API.countDocuments(
                NAME, TYPE, request, DocumentAggregatedResponse.class);
        assertEmptyCountResponse(response);
    }

    @Test
    public void shouldReturnEmptyResponseIfNestedFieldNotPresent() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(NESTED_KEY, attributeValue));

        ResponseEntity<DocumentAggregatedResponse> actualCountResponse = API.countDocuments(
                NAME, TYPE, request, DocumentAggregatedResponse.class);
        assertEmptyCountResponse(actualCountResponse);
    }

    @Test
    public void shouldReturnDocumentCountWithSearchParams() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(ATTRIBUTE_KEY, attributeValue));

        DocumentAggregatedResponse expectedCountResponse =
                new DocumentAggregatedResponse(Lists.newArrayList(
                        new DocumentCountResponse(ImmutableMap.of(ATTRIBUTE_KEY, attributeValue), 2)));

        ResponseEntity<DocumentAggregatedResponse> actualCountResponse = API.countDocuments(
                NAME, TYPE, request, DocumentAggregatedResponse.class);
        assertResponse(actualCountResponse, HttpStatus.OK, expectedCountResponse);
    }

    @Test
    public void shouldReturnDocumentCountWithMultipleGroupByFieldsAndValuesAndNestedDocumentsSearchParams()
            throws InterruptedException {

        String attributeValue2 = randomAlphabetic(20);
        String newNestedKey = "nestedKey.newAttributeKey";
        indexNestedDocument(attributeValue2, randomAlphabetic(20));
        indexNestedDocument(attributeValue2, randomAlphabetic(20));

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(NESTED_KEY, attributeValue));

        //changing groupByFields here
        request.getGroupByFields().remove(0);
        request.getGroupByFields().add(NESTED_KEY);
        request.getGroupByFields().add(newNestedKey);

        List<DocumentCountResponse> expectedAggregations = Lists.newArrayList(
                new DocumentCountResponse(ImmutableMap.of(
                        NESTED_KEY, attributeValue, newNestedKey, newAttributeValue), 1));
        expectedAggregations.add(new DocumentCountResponse(
                ImmutableMap.of(NESTED_KEY, attributeValue, newNestedKey, attributeValue2), 2));
        sortAggregations(expectedAggregations, newNestedKey);
        ResponseEntity<DocumentAggregatedResponse> actualCountResponse = API.countDocuments(
                NAME, TYPE, request, DocumentAggregatedResponse.class);
        sortAggregations(actualCountResponse.getBody().getAggregations(), newNestedKey);
        assertResponse(actualCountResponse, HttpStatus.OK, new DocumentAggregatedResponse(expectedAggregations));
    }

    @Test
    public void shouldReturnDocumentCountWithMultipleGroupByFieldsAndNestedParams() throws InterruptedException {

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        DocumentAggregationRequest request = createCountRequest(ImmutableMap.of(NESTED_KEY, attributeValue));

        //changing groupByFields here
        request.getGroupByFields().remove(0);
        request.getGroupByFields().add(NESTED_KEY);
        request.getGroupByFields().add("nestedKey.newAttributeKey");
        DocumentAggregatedResponse expectedCountResponse =
                new DocumentAggregatedResponse(Lists.newArrayList(
                        new DocumentCountResponse(ImmutableMap.of(NESTED_KEY, attributeValue,
                                "nestedKey.newAttributeKey", newAttributeValue), 1)));

        ResponseEntity<DocumentAggregatedResponse> actualCountResponse = API.countDocuments(
                NAME, TYPE, request, DocumentAggregatedResponse.class);
        assertResponse(actualCountResponse, HttpStatus.OK, expectedCountResponse);
    }

    private void indexDocuments() {

        Map<String, Object> fieldMapPair = new HashMap<>();
        fieldMapPair.put(ATTRIBUTE_KEY, attributeValue);
        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE,
                randomAlphabetic(20), currentTime, currentTime, fieldMapPair);
        documentRequests = documentRequest.getDocumentRequests();
        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(
                documentRequest, SuccessResponse.class);
        assertCreated(createDocumentResponse);
        BatchDocumentRequest documentRequest2 = createBatchDocumentRequestForSingleIndex(NAME, TYPE,
                randomAlphabetic(20), currentTime, currentTime, fieldMapPair);
        documentRequests.addAll(documentRequest2.getDocumentRequests());
        ResponseEntity<SuccessResponse> createSecondDocumentResponse = API.indexDocument(documentRequest2,
                SuccessResponse.class);
        assertCreated(createSecondDocumentResponse);
    }

    private void indexNestedDocument(String newAttributeValue, String nestedDocumentId) {
        Map<String, Object> fieldMapPair = new HashMap<>();
        fieldMapPair.put("nestedKey", ImmutableMap.of(
                ATTRIBUTE_KEY, attributeValue, "newAttributeKey", newAttributeValue));

        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE,
                nestedDocumentId, currentTime, currentTime, fieldMapPair);
        nestedDocumentRequests = documentRequest.getDocumentRequests();
        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(documentRequest,
                SuccessResponse.class);
        assertCreated(createDocumentResponse);
    }

    private String indexDocuments(int numberOfDocuments) {

        String randomValue = randomAlphabetic(20);
        BatchDocumentRequest documentRequest = createBatchDocumentRequestForMultipleIndex(numberOfDocuments);
        documentRequest.getDocumentRequests().stream().forEach(elt -> elt.getFieldMapPair().put(ATTRIBUTE_KEY,
                randomValue));
        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(documentRequest,
                SuccessResponse.class);
        assertCreated(createDocumentResponse);
        documentRequests = documentRequest.getDocumentRequests();
        return randomValue;
    }


    private Map<String, Object> createSearchRequest(String attributeKey, String attributeValue) {

        return prepareSearchRequest(currentTime - DELTA_MILLI_SECONDS, currentTime + DELTA_MILLI_SECONDS,
                ImmutableMap.of(attributeKey, attributeValue));
    }

    private Map<String, Object> createSearchRequestWithPage(String attributeKey, String attributeValue, int page) {

        return prepareSearchRequest(currentTime - DELTA_MILLI_SECONDS, currentTime + DELTA_MILLI_SECONDS,
                ImmutableMap.of(attributeKey, attributeValue, PAGE, page));
    }

    private DocumentAggregationRequest createCountRequest(Map<String, Object> params) {

        return prepareCountRequest(currentTime - DELTA_MILLI_SECONDS, currentTime + DELTA_MILLI_SECONDS, params);
    }
}
