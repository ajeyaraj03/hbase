package com.ekart.facp.dashboard.apis.controller;

import com.ekart.facp.dashboard.apis.BaseIntegrationTest;
import com.ekart.facp.dashboard.apis.dtos.*;
import com.ekart.facp.dashboard.service.dtos.DocumentResult;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ekart.facp.dashboard.apis.DashboardTestUtils.*;
import static com.ekart.facp.dashboard.apis.TestUtils.assertResponse;
import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.*;
import static com.ekart.facp.dashboard.apis.util.ErrorCode.VALIDATION_ERROR;
import static com.ekart.facp.dashboard.service.utility.ErrorCode.BATCH_PROCESSING_FAILED;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

/**
 * Created by avinash.r on 09/05/16.
 */

public class DashboardControllerIntegrationTest extends BaseIntegrationTest {

    private String id;
    private String attributeValue;
    private long currentTime;
    private Map<String, Object> fieldMapPair;
    private Map<String, Object> nestedFieldMapPair;
    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void setUp() {

        id = randomAlphabetic(20);
        attributeValue = randomAlphabetic(20);
        currentTime = System.currentTimeMillis();
        fieldMapPair = new HashMap<>();
        fieldMapPair.put(ATTRIBUTE_KEY + SINGLE_INDEX, attributeValue + SINGLE_INDEX);
        nestedFieldMapPair = new HashMap<>();
        nestedFieldMapPair.put("nestedKey", ImmutableMap.of(ATTRIBUTE_KEY + SINGLE_INDEX,
                attributeValue + SINGLE_INDEX));
    }

    @Test
    public void shouldReturn400IfFieldMapPairIsEmptyWhileInserting() {

        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, ImmutableMap.of());
        ResponseEntity<ErrorMessage> response = API.indexDocument(documentRequest, ErrorMessage.class);
        assertBadRequest(response, VALIDATION_ERROR.name(), "FieldMapPair field cannot be null or empty.");
    }

    @Test
    public void shouldReturn400IfBulkSizeIsMoreThanConfigured() {

        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, ImmutableMap.of());
        for (int i = 0; i < MAX_DOCUMENTS; ++i) {
            documentRequest.getDocumentRequests().add(new DocumentRequest());
        }
        ResponseEntity<ErrorMessage> response = API.indexDocument(documentRequest, ErrorMessage.class);
        assertBadRequest(response, VALIDATION_ERROR.name(), "Bulk size should be less than or equal to 5000.");
    }

    @Test
    public void shouldReturn400IfIndexNotFoundWhileInserting() throws IOException {

        BatchDocumentRequest batchDocumentRequest = createBatchDocumentRequestForSingleIndex("unknown_index", TYPE, id,
                currentTime, currentTime, fieldMapPair);
        ResponseEntity<ErrorMessage> response = API.indexDocument(
                batchDocumentRequest, ErrorMessage.class);
        assertBatchErrorResponse(response, getBatchDocumentResults(batchDocumentRequest.getDocumentRequests()),
                "No index found with : unknown_index");

    }

    @Test
    public void shouldReturn400IfTypeNotFoundWhileInserting() throws IOException {

        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, "type_unknown",
                id, currentTime, currentTime, fieldMapPair);
        ResponseEntity<ErrorMessage> response = API.indexDocument(
                documentRequest, ErrorMessage.class);
        assertBatchErrorResponse(response, getBatchDocumentResults(documentRequest.getDocumentRequests()),
                "No type found with : type_unknown");
    }


    @Test
    public void shouldIndexDocument() throws InterruptedException {

        BatchDocumentRequest batchDocumentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id,
                currentTime, currentTime, fieldMapPair);
        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(
                batchDocumentRequest, SuccessResponse.class);
        assertCreated(createDocumentResponse);

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        assertActualSearchResponse(createSearchRequest(ImmutableMap.of(ATTRIBUTE_KEY + SINGLE_INDEX,
                attributeValue + SINGLE_INDEX)),
                getExpectedSearchResponse(Lists.newArrayList(batchDocumentRequest.getDocumentRequests())));
    }

    @Test
    public void shouldIndexNestedDocument() throws InterruptedException {

        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, nestedFieldMapPair);
        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(documentRequest,
                SuccessResponse.class);
        assertCreated(createDocumentResponse);

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        assertActualSearchResponse(createSearchRequest(ImmutableMap.of(NESTED_KEY + SINGLE_INDEX,
                attributeValue + SINGLE_INDEX)),
                getExpectedSearchResponse(Lists.newArrayList(documentRequest.getDocumentRequests())));
    }


    @Test
    public void shouldUpdateNestedDocument() throws InterruptedException {

        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, nestedFieldMapPair);
        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(documentRequest,
                SuccessResponse.class);
        assertCreated(createDocumentResponse);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, fieldMapPair);
        /*updating version*/
        documentRequest.getDocumentRequests().get(0).setVersion(2);
        createDocumentResponse = API.indexDocument(documentRequest, SuccessResponse.class);
        assertCreated(createDocumentResponse);

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        assertActualSearchResponse(createSearchRequest(ImmutableMap.of(ATTRIBUTE_KEY + SINGLE_INDEX,
                attributeValue + SINGLE_INDEX)),
                getExpectedSearchResponse(Lists.newArrayList(documentRequest.getDocumentRequests())));
    }

    /**
     * Batch test cases
     */

    @Test
    public void shouldFailInsertBatchDocumentIfNoDocumentRequest() throws InterruptedException {
        BatchDocumentRequest documentRequest = createBatchDocumentRequestForMultipleIndex(0);

        ResponseEntity<ErrorMessage> response = API.indexDocument(documentRequest,
                ErrorMessage.class);

        assertBadRequest(response, VALIDATION_ERROR.name(), "[NotEmpty.batchDocumentRequest.documentRequests: Document"
                + " Requests field cannot be null or empty.]");
    }

    @Test
    public void shouldInsertBatchDocument() throws InterruptedException {
        BatchDocumentRequest documentRequest = createBatchDocumentRequestForMultipleIndex(3);

        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(documentRequest,
                SuccessResponse.class);
        assertCreated(createDocumentResponse);

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        Map.Entry<String, Object> fieldMapPairEntryObj = documentRequest.getDocumentRequests().get(0)
                .getFieldMapPair().entrySet()
                .iterator().next();
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(
                NAME, TYPE, createSearchRequest(ImmutableMap.of(fieldMapPairEntryObj.getKey(),
                        fieldMapPairEntryObj.getValue().toString())),
                DocumentSearchResponse.class);

        assertOk(actualSearchResponse);
        assertThat(actualSearchResponse.getBody().getResponse().size(), equalTo(documentRequest
                .getDocumentRequests().size()));
        actualSearchResponse.getBody().getResponse().forEach(s -> assertThat(s.get(fieldMapPairEntryObj.getKey()),
                is(fieldMapPairEntryObj.getValue().toString())));
    }

    @Test
    public void shouldFailBatchDocumentInsert() throws InterruptedException, IOException {
        BatchDocumentRequest documentRequest = createBatchDocumentRequestForMultipleIndex(3);
        /*Same version conflict is success case hence setting same id for both first and
        second request and overriding the version for second/
         */
        documentRequest.getDocumentRequests().get(1).setId(documentRequest.getDocumentRequests().get(0).getId());
        documentRequest.getDocumentRequests().get(2).setId(documentRequest.getDocumentRequests().get(0).getId());
        documentRequest.getDocumentRequests().get(2).setVersion(documentRequest.getDocumentRequests()
                .get(0).getVersion());

        ResponseEntity<ErrorMessage> createDocumentResponse = API.indexDocument(documentRequest,
                ErrorMessage.class);
        List<DocumentResult> documentResults = getBatchDocumentResults(
                Lists.newArrayList(documentRequest.getDocumentRequests().get(2)));

        assertBatchErrorResponse(createDocumentResponse, documentResults,
                "Version mismatched current is : 2 and provided is : 1");

    }

    /**
     * Version related test cases
     */

    @Test
    public void successFullDocumentInsertionOnHigherVersion() throws InterruptedException {
        String newId = randomAlphabetic(20);
        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, newId, currentTime,
                currentTime, nestedFieldMapPair);
        documentRequest.getDocumentRequests().get(0).setVersion(6);

        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(documentRequest,
                SuccessResponse.class);
        assertCreated(createDocumentResponse);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, newId, currentTime,
                currentTime, fieldMapPair);
        documentRequest.getDocumentRequests().get(0).setVersion(9);
        createDocumentResponse = API.indexDocument(documentRequest, SuccessResponse.class);

        assertCreated(createDocumentResponse);

    }

    @Test
    public void sameVersionDocumentInsertionHasToBeHandledAsSuccess() throws InterruptedException {

        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, nestedFieldMapPair);
        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(documentRequest,
                SuccessResponse.class);

        assertCreated(createDocumentResponse);
        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, fieldMapPair);
        createDocumentResponse = API.indexDocument(documentRequest, SuccessResponse.class);

        assertCreated(createDocumentResponse);

    }

    @Test
    public void shouldThrowErrorOnOldVersionDocumentInsertion() throws InterruptedException, IOException {

        BatchDocumentRequest documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, nestedFieldMapPair);
        documentRequest.getDocumentRequests().get(0).setVersion(6);

        ResponseEntity<SuccessResponse> createDocumentResponse = API.indexDocument(documentRequest,
                SuccessResponse.class);
        assertCreated(createDocumentResponse);

        //sleep time is needed because insertion takes some time and we are matching the values inserted and retrieved.
        Thread.sleep(SLEEP_TIME);
        documentRequest = createBatchDocumentRequestForSingleIndex(NAME, TYPE, id, currentTime,
                currentTime, fieldMapPair);
        documentRequest.getDocumentRequests().get(0).setVersion(3);
        ResponseEntity<ErrorMessage> createErrorResponse = API.indexDocument(documentRequest, ErrorMessage.class);

        assertBatchErrorResponse(createErrorResponse, getBatchDocumentResults(documentRequest.getDocumentRequests()),
                "Version mismatched current is : 6 and provided is : 3");

    }

    private Map<String, Object> createSearchRequest(Map<String, Object> attributes) {
        return prepareSearchRequest(currentTime - DELTA_MILLI_SECONDS, currentTime + DELTA_MILLI_SECONDS,
                attributes);
    }

    private void assertActualSearchResponse(Map<String, Object> searchParams,
                                            DocumentSearchResponse expectedSearchResponse) {
        ResponseEntity<DocumentSearchResponse> actualSearchResponse = API.searchDocumentsWithRange(
                NAME, TYPE, searchParams, DocumentSearchResponse.class);
        assertResponse(actualSearchResponse, HttpStatus.OK, expectedSearchResponse);
    }

    private void assertBatchErrorResponse(ResponseEntity<ErrorMessage> createDocumentResponse,
                                          List<DocumentResult> documentExpectedErrorResults,
                                          String message) throws IOException {

        List<DocumentResult> docActualErrorResults = objectMapper.readValue(
                objectMapper.writeValueAsString(createDocumentResponse.getBody().getResponse()),
                new TypeReference<List<DocumentResult>>() {
                });
        /** validating id and failed status */
        assertBadRequest(createDocumentResponse);
        assertThat(createDocumentResponse.getBody().getErrorCode(), is(BATCH_PROCESSING_FAILED.name()));
        for (int docNum = 0; docNum < documentExpectedErrorResults.size(); docNum++) {

            assertThat(documentExpectedErrorResults.get(docNum).getId(),
                    is(docActualErrorResults.get(docNum).getId()));
            assertThat(docActualErrorResults.get(docNum).isSuccess(),
                    is(false));
            assertThat(docActualErrorResults.get(docNum).getMessage(), is(message));
        }

    }
}
