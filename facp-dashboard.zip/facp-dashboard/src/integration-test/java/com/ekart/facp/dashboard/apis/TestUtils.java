package com.ekart.facp.dashboard.apis;

import com.ekart.facp.dashboard.apis.dtos.DocumentSearchResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * @author vijay.daniel
 */
public final class TestUtils {

    private TestUtils() {
    }

    public static <T> void assertResponse(ResponseEntity<T> actualResponse, HttpStatus expectedStatus, T expectedBody) {

        assertThat(actualResponse.getStatusCode(), is(expectedStatus));
        assertReflectionEquals(actualResponse.getBody(), expectedBody);
    }

    public static <T> void assertDocumentSize(ResponseEntity<DocumentSearchResponse> actualResponse, int size,
                                              long totalDocs) {

        assertThat(actualResponse.getStatusCode(), is(HttpStatus.OK));
        assertThat(actualResponse.getBody().getResponse().size(), is(size));
        assertThat(actualResponse.getBody().getTotalCount(), is(totalDocs));
    }
}
