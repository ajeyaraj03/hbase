package com.ekart.facp.dashboard.apis;

import com.ekart.facp.dashboard.apis.dtos.BatchDocumentRequest;
import com.ekart.facp.dashboard.apis.dtos.DocumentAggregationRequest;
import com.google.common.collect.ImmutableMap;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import javax.ws.rs.core.MediaType;

import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by avinash.r on 10/05/16.
 */
public class ApiInterface {

    private RestTemplate client;
    private String host;

    public ApiInterface() {
    }

    private static HttpHeaders newHeader() {

        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        return header;
    }

    private static HttpHeaders newHeader(Map<String, String> headerContent) {
        HttpHeaders header = newHeader();
        headerContent.forEach((k, v) -> header.add(k, v));
        return header;
    }

    private HttpHeaders apiHeaders() {
        Map<String, String> map = new HashMap<>();
        if (StringUtils.hasText("client")) {
            map.put(CLIENT_KEY, "client");
        }
        if (StringUtils.hasText("tenant")) {
            map.put(TENANT_KEY, "tenant");
        }
        return newHeader(map);
    }

    public RestTemplate getClient() {
        return client;
    }

    public void setClient(RestTemplate client) {
        this.client = client;
    }

    public String getHost() {

        return host;
    }

    public void setHost(String host) {

        this.host = host;
    }

    private String url(String urlPath) {

        return url(urlPath, ImmutableMap.of());
    }

    private String url(String urlPath, Map<String, Object> requestParams) {

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        requestParams.forEach((k, v) -> params.add(k, v.toString()));

        UriComponents uriComp = UriComponentsBuilder.newInstance().host(host).path(urlPath).queryParams(params).build();
        return "http:" + uriComp.toUriString();
    }

    public <T> ResponseEntity<T> indexDocument(BatchDocumentRequest request,
                                               Class<T> responseClass) {

        HttpEntity<?> httpRequest = new HttpEntity<>(request, apiHeaders());
        return client.exchange(url("/api/v1/opsearch/documents"), HttpMethod.PUT,
                httpRequest, responseClass);
    }

    public <T> ResponseEntity<T> searchDocuments(String name, String type, Map<String, Object> searchParams,
                                                 Class<T> responseClass) {

        HttpEntity<?> httpRequest = new HttpEntity<>(apiHeaders());
        return client.exchange(url("/api/v1/opsearch/document/search/{name}/{type}/", searchParams), HttpMethod.GET,
                httpRequest, responseClass, name, type);
    }

    public <T> ResponseEntity<T> searchDocumentsWithRange(String name, String type, Map<String, Object> searchParams,
                                                          Class<T> responseClass) {
        HttpEntity<?> httpRequest = new HttpEntity<>(apiHeaders());
        return client.exchange(url("/api/v1/opsearch/document/search/{name}/{type}/range/", searchParams),
                HttpMethod.GET, httpRequest, responseClass, name, type);
    }

    public <T> ResponseEntity<T> countDocuments(String name, String type, DocumentAggregationRequest request,
                                                Class<T> responseClass) {

        HttpEntity<?> httpRequest = new HttpEntity<>(request, apiHeaders());
        return client.exchange(url("/api/v1/opsearch/document/search/{name}/{type}/aggregates/count/"),
                HttpMethod.POST, httpRequest, responseClass, name, type);
    }
}
