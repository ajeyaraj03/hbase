package com.ekart.facp.dashboard.apis.util;

/**
 * Created by avinash.r on 07/07/16.
 *
 * PlaceHolder for future Tenant information.
 */
public class TenantContext {
}
