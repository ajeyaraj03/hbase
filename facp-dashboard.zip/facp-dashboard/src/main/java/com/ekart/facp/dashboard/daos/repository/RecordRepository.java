package com.ekart.facp.dashboard.daos.repository;

import com.ekart.facp.dashboard.daos.models.BulkRecord;
import com.ekart.facp.dashboard.daos.models.SearchResult;
import org.elasticsearch.search.aggregations.Aggregations;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Created by avinash.r on 18/04/16.
 */

@Repository
public interface RecordRepository {

    SearchResult search(String indexName, String typeName, Map<String, Object> searchQueryParams,
                        Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt, int page);

    Aggregations count(String indexName, String typeName, Map<String, Object> searchQueryParams,
                       Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt, final List<String> groupByFields);

    void bulkInsert(List<BulkRecord> records);
}
