package com.ekart.facp.dashboard.service;

import com.ekart.facp.dashboard.apis.util.TenantContext;
import com.ekart.facp.dashboard.service.dtos.Document;
import com.ekart.facp.dashboard.service.dtos.DocumentCountResponse;
import com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse;
import org.springframework.stereotype.Service;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Created by avinash.r on 15/04/16.
 */

@Service
@ThreadSafe
@ParametersAreNonnullByDefault
public interface DashboardService {

    void bulkCreate(TenantContext tenantContext, List<Document> documents);

    DocumentSearchResponse search(TenantContext tenantContext, String name, String type,
                                  Map<String, Object> searchQueryParams,
                                  Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt, Optional<Integer> page);

    List<DocumentCountResponse> count(TenantContext tenantContext, String name, String type,
                                      Map<String, Object> searchQueryParams,
                                      Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt,
                                      List<String> groupByFields);

}
