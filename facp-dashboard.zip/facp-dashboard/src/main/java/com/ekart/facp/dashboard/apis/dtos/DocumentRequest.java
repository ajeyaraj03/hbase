package com.ekart.facp.dashboard.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.validation.constraints.Min;
import java.util.Map;

/**
 * Created by avinash.r on 22/04/16.
 */

@ApiModel
@ParametersAreNonnullByDefault
public class DocumentRequest {

    @ApiModelProperty(name = "name", value = "The name of the entity to be inserted")
    @JsonProperty(value = "name", required = true)
    @NotEmpty(message = "{document.name.notnull}")
    private String name;

    @ApiModelProperty(name = "type", value = "The entity type to be inserted")
    @JsonProperty(value = "type", required = true)
    @NotEmpty(message = "{document.type.notnull}")
    private String type;

    @ApiModelProperty(name = "id", value = "The id of entity to be inserted")
    @JsonProperty(value = "id", required = true)
    @NotEmpty(message = "{document.id.notnull}")
    private String id;

    @ApiModelProperty(name = "field_map_pair", value = "The attributes list")
    @JsonProperty(value = "field_map_pair", required = true)
    @NotEmpty(message = "{document.fieldMapPair.notnull}")
    private Map<String, Object> fieldMapPair;

    @ApiModelProperty(name = "created_at_epoch", value = "Created At time in Epoch")
    @Min(value = 1, message = "{document.createdAtEpoch.notempty}")
    @JsonProperty(value = "created_at_epoch", required = true)
    private long createdAtEpoch;

    @ApiModelProperty(name = "updated_at_epoch", value = "Updated At time in Epoch")
    @Min(value = 1, message = "{document.updatedAtEpoch.notempty}")
    @JsonProperty(value = "updated_at_epoch", required = true)
    private long updatedAtEpoch;

    @ApiModelProperty
    @JsonProperty(value = "version", required = true)
    @Min(value = 1, message = "{document.version.notvalid}")
    private long version;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, Object> getFieldMapPair() {
        return fieldMapPair;
    }

    public void setFieldMapPair(Map<String, Object> fieldMapPair) {
        this.fieldMapPair = fieldMapPair;
    }

    public long getCreatedAtEpoch() {
        return createdAtEpoch;
    }

    public void setCreatedAtEpoch(long createdAtEpoch) {
        this.createdAtEpoch = createdAtEpoch;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    public void setUpdatedAtEpoch(long updatedAtEpoch) {
        this.updatedAtEpoch = updatedAtEpoch;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "DocumentRequest{" + "name='" + name + '\'' + ", type='" + type + '\'' + ", id='" + id + '\''
                + ", fieldMapPair=" + fieldMapPair + ", createdAtEpoch=" + createdAtEpoch
                + ", updatedAtEpoch=" + updatedAtEpoch + ", version=" + version + '}';
    }
}
