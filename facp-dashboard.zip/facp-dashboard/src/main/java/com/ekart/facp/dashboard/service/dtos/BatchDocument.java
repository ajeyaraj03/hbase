package com.ekart.facp.dashboard.service.dtos;

import java.util.List;

/**
 * Created by ajeya.hb on 19/06/16.
 */
public class BatchDocument {

    private List<Document> documents;

    public List<Document> getDocuments() {
        return documents;
    }

    public void setDocuments(List<Document> documents) {
        this.documents = documents;
    }

    @Override
    public String toString() {
        return "BatchDocument{"
                + "documents=" + documents
                + '}';
    }
}
