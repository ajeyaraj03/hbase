package com.ekart.facp.dashboard.service.exceptions;

/**
 * Created by avinash.r on 02/06/16.
 */

import static com.ekart.facp.dashboard.service.utility.ErrorCode.TYPE_NOT_FOUND;

public class TypeNotFoundException extends BaseException {

    private static final long serialVersionUID = 2881948689339847703L;

    public TypeNotFoundException(String typeName, Throwable cause) {

        super("No type found with : " + typeName, TYPE_NOT_FOUND.name(), cause);
    }
}
