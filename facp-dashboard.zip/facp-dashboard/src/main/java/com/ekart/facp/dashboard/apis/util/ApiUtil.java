package com.ekart.facp.dashboard.apis.util;

/**
 * Created by avinash.r on 07/08/16.
 */
public final class ApiUtil {

    private ApiUtil() {
    }

    public static TenantContext tenantContext(String tenantName) {
        return new TenantContext();
    }
}
