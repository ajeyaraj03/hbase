package com.ekart.facp.dashboard.service.utility;

/**
 * Created by ajeya.hb on 06/07/16.
 */
public enum ErrorCode {
    BATCH_PROCESSING_FAILED,
    DOCUMENT_NOT_FOUND,
    INDEX_NOT_FOUND,
    INVALID_INPUT,
    TYPE_NOT_FOUND,
    VERSION_MISMATCHED
}
