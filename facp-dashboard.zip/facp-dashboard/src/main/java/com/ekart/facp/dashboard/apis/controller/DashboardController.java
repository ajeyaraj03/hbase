package com.ekart.facp.dashboard.apis.controller;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.dashboard.apis.dtos.BatchDocumentRequest;
import com.ekart.facp.dashboard.apis.dtos.ErrorMessage;
import com.ekart.facp.dashboard.apis.dtos.SuccessResponse;
import com.ekart.facp.dashboard.apis.mappers.ApiDtoToServiceDtoMapper;
import com.ekart.facp.dashboard.service.DashboardService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.eclipse.jetty.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.MediaType;

import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.*;
import static com.ekart.facp.dashboard.apis.util.ApiUtil.tenantContext;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by avinash.r on 18/04/16.
 */

@Api(protocols = "http")
@ThreadSafe
@RestController
@RequestMapping("/api/v1/opsearch")
@ParametersAreNonnullByDefault
public class DashboardController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardController.class);

    private final DashboardService dashboardService;
    private final ApiDtoToServiceDtoMapper mapper;

    public DashboardController(DashboardService dashboardService, ApiDtoToServiceDtoMapper mapper) {

        checkNotNull(dashboardService);
        checkNotNull(mapper);
        this.dashboardService = dashboardService;
        this.mapper = mapper;
    }

    @ApiOperation(nickname = "index", value = "Create document in elastic search cluster",
            notes = "Response is document id of document stored in elastic search")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.CREATED_201, message = "Document created successfully",
                    response = SuccessResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400, message = "Mandatory params are not present.",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})

    @Timed
    @ExceptionMetered
    @RequestMapping(value = "/documents", method = RequestMethod.PUT,
            consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<SuccessResponse> indexDocument(@RequestBody @Valid
                                                 @NotNull BatchDocumentRequest batchRequest,
                                                 @RequestHeader(value = CLIENT_KEY, required = false) String client,
                                                 @RequestHeader(value = TENANT_KEY, required = false) String tenant) {
        LOGGER.trace("Indexing documents for client {}", client);
        dashboardService.bulkCreate(tenantContext(tenant),
                mapper.batchDocumentRequestTobatchDocument(batchRequest).getDocuments());
        return created(new SuccessResponse());
    }

}
