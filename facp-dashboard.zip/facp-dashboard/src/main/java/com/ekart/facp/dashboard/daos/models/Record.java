package com.ekart.facp.dashboard.daos.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Field;

import java.util.Map;

/**
 * Created by avinash.r on 18/04/16.
 * <p>
 * To create index
 * $ curl -XPUT 'http://localhost:9200/inventory/' -d
 * '{ "settings" : { "number_of_shards" : 3, "number_of_replicas" : 2 } }’
 */
public class Record {

    @Id
    @Field
    private String id;

    @Field
    private Map<String, Object> data;

    public Record() {
    }

    public Record(String id, Map<String, Object> data) {
        this.id = id;
        this.data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Record{" + "id='" + id + '\''
                + ", data=" + data + '}';
    }
}

