package com.ekart.facp.dashboard.apis.mappers;

import com.ekart.facp.dashboard.apis.dtos.BatchDocumentRequest;
import com.ekart.facp.dashboard.apis.dtos.DocumentCountResponse;
import com.ekart.facp.dashboard.apis.dtos.DocumentRequest;
import com.ekart.facp.dashboard.apis.dtos.DocumentSearchResponse;
import com.ekart.facp.dashboard.service.dtos.BatchDocument;
import com.ekart.facp.dashboard.service.dtos.Document;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by avinash.r on 08/06/16.
 */
@Component
@Mapper(componentModel = "spring")
public interface ApiDtoToServiceDtoMapper {

    List<Document> documentRequestsToDocumentCreates(List<DocumentRequest> documentRequests);

    @Mapping(source = "fieldMapPair", target = "params")
    Document documentRequestToDocumentCreate(DocumentRequest documentRequest);

    @Mapping(source = "documentRequests", target = "documents")
    BatchDocument batchDocumentRequestTobatchDocument(BatchDocumentRequest documentRequest);

    DocumentCountResponse serviceCountResponseToApiResponse(
            com.ekart.facp.dashboard.service.dtos.DocumentCountResponse serviceResponse);

    DocumentSearchResponse serviceSearchResponseToApiResponse(
            com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse serviceResponse);
}
