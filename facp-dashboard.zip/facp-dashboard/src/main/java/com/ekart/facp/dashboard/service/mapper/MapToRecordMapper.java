package com.ekart.facp.dashboard.service.mapper;

import com.ekart.facp.dashboard.daos.models.Record;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Created by avinash.r on 18/05/16.
 */

@Component
@Mapper(componentModel = "spring")
public interface MapToRecordMapper {

    @Mappings({
            @Mapping(source = "id", target = "id"),
            @Mapping(source = "params", target = "data")
    })
    Record mapToRecord(String id, Map<String, Object> params);
}
