package com.ekart.facp.dashboard.service.dtos;

import java.util.Map;

/**
 * Created by ajeya.hb on 19/06/16.
 */
public class Document {
    private String id;
    private String name;
    private String type;
    private Map<String, Object> params;
    private long createdAtEpoch;
    private long updatedAtEpoch;
    private long version;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

    public long getCreatedAtEpoch() {
        return createdAtEpoch;
    }

    public void setCreatedAtEpoch(long createdAtEpoch) {
        this.createdAtEpoch = createdAtEpoch;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    public void setUpdatedAtEpoch(long updatedAtEpoch) {
        this.updatedAtEpoch = updatedAtEpoch;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "Document{" + "id='" + id + '\'' + ", name='" + name + '\'' + ", type='" + type + '\''
                + ", params=" + params + ", createdAtEpoch=" + createdAtEpoch + ", updatedAtEpoch="
                + updatedAtEpoch + ", version=" + version + '}';
    }
}
