package com.ekart.facp.dashboard.service;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.dashboard.apis.util.TenantContext;
import com.ekart.facp.dashboard.daos.models.BulkRecord;
import com.ekart.facp.dashboard.daos.models.Record;
import com.ekart.facp.dashboard.daos.models.SearchResult;
import com.ekart.facp.dashboard.daos.repository.RecordRepository;
import com.ekart.facp.dashboard.service.dtos.Document;
import com.ekart.facp.dashboard.service.dtos.DocumentCountResponse;
import com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse;
import com.ekart.facp.dashboard.service.mapper.MapToRecordMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.*;
import static com.ekart.facp.dashboard.service.utility.CommonHelper.withDocumentPrefix;
import static com.ekart.facp.dashboard.service.utility.Constants.*;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by avinash.r on 12/05/16.
 */
@Service
@ThreadSafe
@ParametersAreNonnullByDefault
public class DashboardServiceImpl implements DashboardService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardService.class);

    private final RecordRepository recordRepository;
    private final MapToRecordMapper mapper;

    public DashboardServiceImpl(RecordRepository recordRepository, MapToRecordMapper mapper) {

        this.recordRepository = checkNotNull(recordRepository);
        this.mapper = checkNotNull(mapper);
    }

    @Timed
    @ExceptionMetered
    @Override
    public void bulkCreate(TenantContext tenantContext, List<Document> documents) {

        List<BulkRecord> records = Lists.newArrayListWithExpectedSize(documents.size());
        documents.forEach(document -> {
            Record record = prepareRecord(document.getType(),
                    document.getId(),
                    document.getParams(),
                    document.getCreatedAtEpoch(),
                    document.getUpdatedAtEpoch());
            records.add(new BulkRecord(document.getName(), document.getType(), document.getVersion(), record));
        });
        recordRepository.bulkInsert(records);
    }

    @Timed
    @ExceptionMetered
    @Override
    public DocumentSearchResponse search(TenantContext tenantContext,
                                         String name, String type, Map<String, Object> searchQueryParams,
                                         Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt,
                                         Optional<Integer> page) {

        searchQueryParams.remove(FROM_CREATED_AT);
        searchQueryParams.remove(TO_CREATED_AT);
        searchQueryParams.remove(PAGE);
        LOGGER.trace("Started searching document with name: {} and type: {}", name, type);

        page = page.isPresent() ? page : Optional.of(DEFAULT_PAGE);
        SearchResult searchResult = recordRepository.search(name, type, searchQueryParams, fromCreatedAt, toCreatedAt,
                page.get());
        return new DocumentSearchResponse(searchResult.getRecords().stream().map(elt -> elt.getData())
                .collect(Collectors.toList()), searchResult.getTotalCount());
    }

    /**
     * This method creates a view which has all the groupByFields as columns with one extra column as docCount,
     * e.g if we have two groupByFields, then view will be like
     * -------------------------------------------
     * | groupByField1 | groupByField2 | doc_count |
     * -------------------------------------------
     * |               |               |           |
     * -------------------------------------------
     * then it creates the response like
     * [
     * {
     * "groupByFieldsAndValues" : {
     * "groupByField1" : "value1"
     * "groupByField2" : "value2"
     * },
     * "documentCount" : 2
     * },
     * {
     * "groupByFieldsAndValues" : {
     * "groupByField1" : "value1"
     * "groupByField2" : "value3"
     * },
     * "documentCount" : 1
     * }
     * ]
     *
     * @param name
     * @param type
     * @param searchQueryParams
     * @param fromCreatedAt
     * @param toCreatedAt
     * @param groupByFields
     * @return
     */
    @Timed
    @ExceptionMetered
    @Override
    public List<DocumentCountResponse> count(TenantContext tenantContext, String name, String type,
                                             Map<String, Object> searchQueryParams,
                                             Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt,
                                             List<String> groupByFields) {

        LOGGER.trace("Started counting document with name: {} and type: {}", name, type);
        List<String> distinctGroupByFields = groupByFields.stream().distinct().collect(Collectors.toList());
        Aggregations aggregations = recordRepository.count(name, type,
                searchQueryParams, fromCreatedAt, toCreatedAt, distinctGroupByFields);
        Terms aggregationTerms = aggregations.get(withDocumentPrefix(distinctGroupByFields.get(0)));
        List<DocumentCountResponse> responses = Lists.newArrayList();
        createAggregationView(aggregationTerms.getBuckets(), responses, Maps.newLinkedHashMap(), groupByFields, 0);
        return responses;
    }

    /**
     * Recursive code to generate table from the aggregated buckets returned by repository
     *
     * @param buckets
     * @param responses
     * @param currentContext
     * @param groupByFields
     * @param groupByFieldIndex
     */
    private void createAggregationView(List<Terms.Bucket> buckets, List<DocumentCountResponse> responses,
                                       Map<String, Object> currentContext,
                                       List<String> groupByFields, int groupByFieldIndex) {

        String currentField = groupByFields.get(groupByFieldIndex);
        for (Terms.Bucket bucket : buckets) {

            currentContext.put(currentField, bucket.getKey());
            if (groupByFieldIndex == groupByFields.size() - 1) {

                responses.add(new DocumentCountResponse(Maps.newLinkedHashMap(currentContext), bucket.getDocCount()));

            } else {

                int nextFieldIndex = groupByFieldIndex + 1;
                String nextFieldAggs = groupByFields.get(nextFieldIndex);
                Terms aggregationTerms = bucket.getAggregations().<Terms>get(withDocumentPrefix(nextFieldAggs));
                createAggregationView(aggregationTerms.getBuckets(), responses, currentContext,
                        groupByFields, nextFieldIndex);
            }
            currentContext.remove(currentField);
        }

    }

    private Record prepareRecord(String type, String id, Map<String, Object> insertParams, long epochCreatedAt,
                                 long epochUpdatedAt) {

        insertParams.put(CREATED_AT_EPOCH, epochCreatedAt);
        insertParams.put(UPDATED_AT_EPOCH, epochUpdatedAt);
        return mapper.mapToRecord(generateDocumentId(type, id), insertParams);
    }

    private static String generateDocumentId(String type, String id) {

        return String.join(":", type, id);
    }
}
