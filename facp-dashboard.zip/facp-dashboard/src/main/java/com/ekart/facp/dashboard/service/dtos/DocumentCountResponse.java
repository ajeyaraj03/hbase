package com.ekart.facp.dashboard.service.dtos;

import java.util.Map;

/**
 * Created by avinash.r on 07/06/16.
 */
public class DocumentCountResponse {

    private Map<String, Object> groupByFieldsAndValues;
    private long documentCount;

    public DocumentCountResponse() {
    }

    public DocumentCountResponse(Map<String, Object> groupByFieldsAndValues, long documentCount) {
        this.groupByFieldsAndValues = groupByFieldsAndValues;
        this.documentCount = documentCount;
    }

    public Map<String, Object> getGroupByFieldsAndValues() {
        return groupByFieldsAndValues;
    }

    public void setGroupByFieldsAndValues(Map<String, Object> groupByFieldsAndValues) {
        this.groupByFieldsAndValues = groupByFieldsAndValues;
    }

    public long getDocumentCount() {
        return documentCount;
    }

    public void setDocumentCount(long documentCount) {
        this.documentCount = documentCount;
    }

    @Override
    public String toString() {
        return "DocumentCountResponse{"
                + "groupByFieldsAndValues=" + groupByFieldsAndValues
                + ", documentCount=" + documentCount + '}';
    }
}
