package com.ekart.facp.dashboard.service.utility;

import com.ekart.facp.dashboard.service.dtos.DocumentResult;
import com.google.common.collect.Lists;

import java.util.List;
import java.util.Map;

/**
 * Created by avinash.r on 30/07/16.
 */
@SuppressWarnings("checkstyle:magicnumber")
public final class EsErrorMessageParser {

    private EsErrorMessageParser() {
    }

    public static List<DocumentResult> parseToDocumentResult(Map<String, String> failedDocuments) {

        List<DocumentResult> documentResults = Lists.newArrayList();
        failedDocuments.entrySet().forEach(document -> {

            String errorMessage = document.getValue();
            String indexName = errorMessage.substring(errorMessage.indexOf("[[") + 2, errorMessage.indexOf(']'));
            String type = document.getKey().substring(0, document.getKey().indexOf(":"));
            String id = document.getKey().substring(document.getKey().indexOf(":") + 1);

            if (errorMessage.contains("IndexMissingException")) {

                //e.g "someType9:uuid-inv-1": "IndexMissingException[[inventory1] missing]"
                documentResults.add(new DocumentResult(indexName, type, id, false,
                        "No index found with : " + indexName));

            } else if (errorMessage.contains("TypeMissingException")) {

                //e.g "someType9:uuid-inv-1": "TypeMissingException[[inventory] type[[someType9, trying to auto create
                // mapping, but dynamic mapping is disabled]] missing]"
                documentResults.add(new DocumentResult(indexName, type, id, false,
                        "No type found with : " + type));

            } else if (errorMessage.contains("VersionConflictEngineException")) {

                //e.g "bag:uuid-inv-1": "VersionConflictEngineException[[inventory][0] [bag][bag:uuid-inv-1]:
                // version conflict, current [1], provided [1]]"
                String[] splitArray = errorMessage.split("\\[|\\]");
                String currentVersion = splitArray[splitArray.length - 3];
                String providedVersion = splitArray[splitArray.length - 1];

                /** Same version case is handled as success.If not Varadhi requests will go in loop because
                 *  batch api response is exposed as HTTP-400 for any one record failure. Varadhi will retry
                 *  entire request again, these requests will fail repeatedly with Same version
                 *  conflict errors  */
                if (!currentVersion.equals(providedVersion)) {
                    documentResults.add(new DocumentResult(indexName, type, id, false,
                            "Version mismatched current is : " + currentVersion
                                    + " and provided is : " + providedVersion));
                }

            } else {
                documentResults.add(new DocumentResult(indexName, type, id, false, errorMessage));
            }
        });
        return documentResults;
    }
}
