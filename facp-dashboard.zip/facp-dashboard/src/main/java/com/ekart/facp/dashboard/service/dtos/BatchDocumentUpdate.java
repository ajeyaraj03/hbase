package com.ekart.facp.dashboard.service.dtos;

/**
 * Created by ajeya.hb on 19/06/16.
 */
public class BatchDocumentUpdate {
}
