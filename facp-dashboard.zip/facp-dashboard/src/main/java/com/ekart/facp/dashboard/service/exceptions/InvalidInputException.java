package com.ekart.facp.dashboard.service.exceptions;

/**
 * Created by avinash.r on 16/05/16.
 */

import static com.ekart.facp.dashboard.service.utility.ErrorCode.INVALID_INPUT;

public class InvalidInputException extends BaseException {

    private static final long serialVersionUID = 8058697465409800797L;

    public InvalidInputException(Throwable cause) {

        super("Input can not be processed, Provide it in proper format.", INVALID_INPUT.name(), cause);
    }
}
