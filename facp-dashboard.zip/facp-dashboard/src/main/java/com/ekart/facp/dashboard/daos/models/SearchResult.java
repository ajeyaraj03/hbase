package com.ekart.facp.dashboard.daos.models;

import com.google.common.collect.Lists;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;

import java.util.List;
import java.util.Map;

import static com.ekart.facp.dashboard.service.utility.Constants.DATA;

/**
 * Created by avinash.r on 10/06/16.
 */
public class SearchResult {

    private List<Record> records;
    private long totalCount;

    public SearchResult() {
    }

    public SearchResult(List<Record> records, long totalCount) {
        this.records = records;
        this.totalCount = totalCount;
    }

    public static SearchResult getSearchResultFromResponse(SearchResponse response) {
        List<Record> records = Lists.newArrayListWithExpectedSize(response.getHits().getHits().length);
        for (SearchHit hit : response.getHits().getHits()) {
            records.add(new Record(hit.getId(), (Map)hit.getSource().get(DATA)));
        }
        return new SearchResult(records, response.getHits().getTotalHits());
    }

    public List<Record> getRecords() {
        return records;
    }

    public void setRecords(List<Record> records) {
        this.records = records;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotal(long totalCount) {
        this.totalCount = totalCount;
    }

    @Override
    public String toString() {
        return "SearchResult{" + "records=" + records + ", totalCount=" + totalCount + '}';
    }
}
