package com.ekart.facp.audit.apis.dtos.audit;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * Created by akshit.agarwal on 29/05/16.
 */
@ApiModel(value = "Search response", description = "Response containing audit entities searched for a given entity "
        + "and time range")
public class EntityAuditSearchResponse {
    @ApiModelProperty(name = "audit_entries", value = "List of audit entries for the mentioned entity_name "
            + "and entity_id")
    @JsonProperty(value = "audit_entries")
    private List<AuditEntity> auditEntries;

    public List<AuditEntity> getAuditEntries() {
        return auditEntries;
    }

    public void setAuditEntries(List<AuditEntity> auditEntries) {
        this.auditEntries = auditEntries;
    }

    @Override
    public String toString() {
        return "EntityAuditSearchResponse{"
                + ", auditEntries=" + auditEntries
                + '}';
    }
}
