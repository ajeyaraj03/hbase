package com.ekart.facp.audit.apis.exception;

import com.ekart.facp.audit.common.exceptions.ValidationException;

import static com.ekart.facp.audit.common.enums.ErrorCode.VALIDATION_ERROR;


/**
 * Created by akshit.agarwal on 31/05/16.
 */
public class InvalidInputException extends ValidationException {
    private static final long serialVersionUID = -8281691324872630889L;

    public InvalidInputException(String message) {
        super(message, VALIDATION_ERROR.name());
    }
}
