package com.ekart.facp.audit.dal.exception;

import com.ekart.facp.audit.common.exceptions.ValidationException;

import static com.ekart.facp.audit.common.enums.ErrorCode.SERIALIZATION_FAILED;

/**
 * Created by akshit.agarwal on 28/05/16.
 */
public class SerializationException extends ValidationException {
    private static final long serialVersionUID = -6280232754741273315L;

    public SerializationException(String key, Object value, Throwable cause) {
        super("Unable to Serialize columnValue (key: " + key
                + ", value: " + value
                + ")", SERIALIZATION_FAILED.name(), cause);
    }

    public SerializationException(String message) {
        super(message, SERIALIZATION_FAILED.name());
    }
}
