package com.ekart.facp.audit.apis.util;

import com.ekart.facp.audit.common.util.TenantContext;

/**
 * Created by akshit.agarwal on 31/06/16.
 */
public final class ApiUtil {

   public static final String CLIENT_KEY = "X-Ekart-Client";
   public static final String TENANT_KEY = "X-Tenant-Context";
   public static final String ENTITY_NAME = "entityName";
   public static final String ENTITY_ID = "entityId";
   public static final String FROM_TIMESTAMP = "fromTimestamp";
   public static final String TO_TIMESTAMP = "toTimestamp";

   private ApiUtil() {

   }

   public static TenantContext tenantContext(String tenantName) {
      return new TenantContext();
   }
}
