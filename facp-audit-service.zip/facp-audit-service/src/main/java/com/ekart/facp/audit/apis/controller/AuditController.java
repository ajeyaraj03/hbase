package com.ekart.facp.audit.apis.controller;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.audit.apis.dtos.ErrorMessage;
import com.ekart.facp.audit.apis.dtos.audit.BatchAuditEntityCreationRequest;
import com.ekart.facp.audit.apis.dtos.audit.EntityAuditSearchResponse;
import com.ekart.facp.audit.apis.dtos.audit.SuccessResponse;
import com.ekart.facp.audit.apis.mapper.ApiServiceDtoMapper;
import com.ekart.facp.audit.apis.util.Validator;
import com.ekart.facp.audit.service.AuditService;
import com.ekart.facp.audit.service.dtos.AuditResponse;
import com.ekart.facp.audit.apis.exception.BatchProcessingException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.eclipse.jetty.http.HttpStatus;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.Valid;
import javax.ws.rs.core.MediaType;
import java.util.List;
import java.util.stream.Collectors;

import static com.ekart.facp.audit.apis.util.ApiUtil.*;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by akshit.agarwal on 23/05/16.
 */

@ThreadSafe
@RestController
@ParametersAreNonnullByDefault
@RequestMapping("/api/v1/audit/entities")
@Api(protocols = "http", tags = "Audit Service")
public class AuditController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditController.class);
    private final AuditService auditService;
    private final ApiServiceDtoMapper mapper;

    public AuditController(AuditService auditService, ApiServiceDtoMapper mapper) {
        this.auditService = checkNotNull(auditService);
        this.mapper = checkNotNull(mapper);
    }

    @ApiOperation(nickname = "BatchAuditEntryIngestion", value = "Store all the entities with their audit details"
            + "in the datastore")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.CREATED_201,
                    message = "Audit entries is created successfully", response = SuccessResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Audit Creation for failed for 1/more audit entries", response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.FORBIDDEN_403,
                    message = "Client is not authorised to make this call.", response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON,
            produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<SuccessResponse> bulkCreate(@RequestBody @Validated
                                                          BatchAuditEntityCreationRequest request,
                                                      @RequestHeader(value = CLIENT_KEY, required = false)
                                                      String client,
                                                      @RequestHeader(value = TENANT_KEY, required = false)
                                                      String tenant) {

        LOGGER.debug("Received request for bulk data Ingestion from client: {}", client);
        List<AuditResponse> auditResponses = auditService.bulkCreate(tenantContext(tenant),
                mapper.apiToServiceBatchAuditEntityCreationRequest(request));

        List<AuditResponse> failedAuditResponses = auditResponses.stream()
                .filter(auditResponse -> !auditResponse.isSuccess())
                .collect(Collectors.toList());

        if (!failedAuditResponses.isEmpty()) {
            throw new BatchProcessingException("Failed to Process Batch Audit Creation",
                    mapper.serviceToApiFailedAuditResponses(failedAuditResponses));
        }

        return created(new SuccessResponse());
    }


    @ApiOperation(nickname = "FetchAuditEntries", value = "Get the entity Audit for the given timerange")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200,
                    message = "Request is processed successfully", response = EntityAuditSearchResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Invalid request for fetching entity audit", response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.FORBIDDEN_403,
                    message = "Client is not authorised to make this call.", response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(path = "/{entityName}/{entityId}", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<EntityAuditSearchResponse> getEntityAudit(
            @PathVariable(value = ENTITY_NAME) @Valid @NotEmpty String entityName,
            @PathVariable(value = ENTITY_ID) @Valid @NotEmpty String entityId,
            @RequestParam(value = FROM_TIMESTAMP) long fromTimestamp,
            @RequestParam(value = TO_TIMESTAMP) long toTimestamp,
            @RequestParam()
            @RequestHeader(value = CLIENT_KEY, required = false) String client,
            @RequestHeader(value = TENANT_KEY, required = false) String tenant) {

        LOGGER.debug("Received request for fetching audit data from client: {}", client);

        Validator.validatePositiveLong(fromTimestamp, FROM_TIMESTAMP);
        Validator.validatePositiveLong(toTimestamp, TO_TIMESTAMP);
        Validator.validateFromAndToTimestamp(fromTimestamp, toTimestamp);

        return ok(mapper.serviceToApiEntityAuditSearchResponse(
                auditService.findEntries(tenantContext(tenant), entityName, entityId, fromTimestamp, toTimestamp)
        ));
    }
}
