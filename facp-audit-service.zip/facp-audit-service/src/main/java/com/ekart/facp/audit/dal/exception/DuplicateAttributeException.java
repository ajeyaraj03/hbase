package com.ekart.facp.audit.dal.exception;

import com.ekart.facp.audit.common.exceptions.ValidationException;
import com.ekart.facp.audit.dal.dtos.AuditEntity;

import static com.ekart.facp.audit.common.enums.ErrorCode.DUPLICATE_ATTRIBUTE_DETECTED;

/**
 * Created by akshit.agarwal on 25/07/16.
 */
public class DuplicateAttributeException extends ValidationException {
    private static final long serialVersionUID = 8577070936817701815L;

    public DuplicateAttributeException(AuditEntity auditEntity, String attributeName) {
        super("AuditEntity: " + auditEntity + " contains key: " + attributeName, DUPLICATE_ATTRIBUTE_DETECTED.name());
    }
}
