package com.ekart.facp.audit.apis.config.spring;

import com.ekart.facp.audit.apis.util.HbaseConfigUtil;
import com.ekart.facp.audit.apis.util.HbaseConnector;
import com.ekart.facp.audit.dal.AuditEntityRepository;
import com.ekart.facp.audit.dal.HbaseRepositoryImpl;
import com.ekart.facp.audit.dal.ddl.AuditDDLUtility;
import com.ekart.facp.audit.dal.ddl.HbaseDDLUtility;
import com.ekart.facp.audit.dal.util.HbaseKeyGenerator;
import com.ekart.facp.audit.dal.util.HbaseUtility;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.inject.Inject;

/**
 * Created by akshit.agarwal on 30/05/16.
 */
@Configuration
@Import({HbaseConfigUtil.class})
public class RepositoryConfig {
    @Inject
    private ObjectMapper objectMapper;

    @Inject
    private HbaseConfigUtil hbaseConfigUtil;

    @Bean
    public AuditEntityRepository auditEntityRepository() {
        return new HbaseRepositoryImpl(hbaseConnector().hbaseTemplate(), objectMapper, keyGenerator(), hbaseUtility());
    }

    @Bean
    public AuditDDLUtility auditDDLUtility() {
        return new HbaseDDLUtility(hbaseConnector().getAdmin(), hbaseConfigUtil.getHbaseTableConfig());
    }

    @Bean
    public HbaseKeyGenerator keyGenerator() {
        return new HbaseKeyGenerator();
    }

    @Bean
    public HbaseUtility hbaseUtility() {
        return new HbaseUtility(objectMapper);
    }

    @Bean
    public HbaseConnector hbaseConnector() {
        return new HbaseConnector(hbaseConfigUtil);
    }
}
