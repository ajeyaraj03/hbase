package com.ekart.facp.audit.apis.dtos.audit;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;

/**
 * We can add more params as and when required in creationConfig.
 * { NAME, BLOOMFILTER, VERSIONS , IN_MEMORY, KEEP_DELETED_CELLS,
 *   DATA_BLOCK_ENCODING, TTL, COMPRESSION, MIN_VERSIONS',
 *   BLOCKCACHE, BLOCKSIZE', REPLICATION_SCOPE }
 *
 *  Created by akshit.agarwal on 22/06/16.
 */
@Immutable
@ParametersAreNonnullByDefault
public class HbaseTableConfig {
    private final int regionReplication;

    public HbaseTableConfig(int regionReplication) {
        this.regionReplication = regionReplication;
    }

    public int getRegionReplication() {
        return regionReplication;
    }

    @Override
    public String toString() {
        return "HbaseTableConfig{"
                + "regionReplication=" + regionReplication
                + '}';
    }
}
