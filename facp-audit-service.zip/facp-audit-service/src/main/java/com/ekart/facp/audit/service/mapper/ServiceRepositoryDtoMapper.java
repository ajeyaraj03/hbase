package com.ekart.facp.audit.service.mapper;

import com.ekart.facp.audit.service.dtos.AuditEntity;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by akshit.agarwal on 07/06/16.
 */

@Component
@Mapper(componentModel = "spring")
public abstract class ServiceRepositoryDtoMapper {

    protected com.ekart.facp.audit.dal.dtos.AuditEntity serviceToRepositoryAuditEntity(AuditEntity auditEntity) {
        return new com.ekart.facp.audit.dal.dtos.AuditEntity(auditEntity.getEntityName(),
                auditEntity.getEntityId(),
                auditEntity.getEntityVersion(),
                auditEntity.getEntityType(),
                auditEntity.getCreatedByActor(),
                auditEntity.getCreatedAtEpoch(),
                auditEntity.getUpdatedByActor(),
                auditEntity.getUpdatedAtEpoch(),
                auditEntity.getUpdatedByProcessId(),
                auditEntity.getFacilityId(),
                auditEntity.getDataAttributes());
    }

    public abstract List<com.ekart.facp.audit.dal.dtos.AuditEntity> serviceToRepositoryAuditEntities(List<AuditEntity>
                                                                               auditEntities);

    protected AuditEntity repositoryToServiceAuditEntity(com.ekart.facp.audit.dal.dtos.AuditEntity auditEntity) {
        return new AuditEntity(auditEntity.getEntityName(),
                auditEntity.getEntityId(),
                auditEntity.getEntityVersion(),
                auditEntity.getEntityType(),
                auditEntity.getCreatedByActor(),
                auditEntity.getCreatedAtEpoch(),
                auditEntity.getUpdatedByActor(),
                auditEntity.getUpdatedAtEpoch(),
                auditEntity.getUpdatedByProcessId(),
                auditEntity.getFacilityId(),
                auditEntity.getDataAttributes());
    }

    public abstract List<AuditEntity> repositoryToServiceAuditEntities(List<com.ekart.facp.audit.dal.dtos.AuditEntity>
                                                                               auditEntities);
}
