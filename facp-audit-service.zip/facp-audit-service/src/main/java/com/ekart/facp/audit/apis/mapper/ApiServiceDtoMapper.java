package com.ekart.facp.audit.apis.mapper;

import com.ekart.facp.audit.apis.dtos.audit.AuditEntity;
import com.ekart.facp.audit.apis.dtos.audit.BatchAuditEntityCreationRequest;
import com.ekart.facp.audit.apis.dtos.audit.EntityAuditSearchResponse;
import com.ekart.facp.audit.apis.dtos.audit.FailedAuditResponse;
import com.ekart.facp.audit.service.dtos.AuditResponse;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by akshit.agarwal on 27/06/16.
 */
@Component
@Mapper(componentModel = "spring")
public abstract class ApiServiceDtoMapper {

    protected com.ekart.facp.audit.service.dtos.AuditEntity apiToServiceAuditEntity(AuditEntity apiAuditEntity) {
        return new com.ekart.facp.audit.service.dtos.AuditEntity(
                apiAuditEntity.getEntityName(),
                apiAuditEntity.getEntityId(),
                apiAuditEntity.getEntityVersion(),
                apiAuditEntity.getEntityType(),
                apiAuditEntity.getCreatedByActor(),
                apiAuditEntity.getCreatedAtEpoch(),
                apiAuditEntity.getUpdatedByActor(),
                apiAuditEntity.getUpdatedAtEpoch(),
                apiAuditEntity.getUpdatedByProcessId(),
                apiAuditEntity.getFacilityId(),
                apiAuditEntity.getDataAttributes());
    }

    protected abstract AuditEntity serviceToApiAuditEntity(
            com.ekart.facp.audit.service.dtos.AuditEntity serviceAuditEntry);

    protected abstract List<com.ekart.facp.audit.service.dtos.AuditEntity> apiToServiceAuditEntities(
            List<AuditEntity> auditEntities);

    protected abstract List<AuditEntity> serviceToApiAuditEntities(
            List<com.ekart.facp.audit.service.dtos.AuditEntity> auditEntries);

    public com.ekart.facp.audit.service.dtos.BatchAuditEntityCreationRequest
    apiToServiceBatchAuditEntityCreationRequest(BatchAuditEntityCreationRequest batchCreationRequest) {
        return new com.ekart.facp.audit.service.dtos.BatchAuditEntityCreationRequest(
                apiToServiceAuditEntities(batchCreationRequest.getAuditEntities())
        );
    }

    protected abstract FailedAuditResponse serviceToApiFailedAuditResponse(AuditResponse auditResponse);

    public abstract List<FailedAuditResponse> serviceToApiFailedAuditResponses(List<AuditResponse> auditResponses);

    public EntityAuditSearchResponse serviceToApiEntityAuditSearchResponse(
            List<com.ekart.facp.audit.service.dtos.AuditEntity> auditEntities) {

        EntityAuditSearchResponse entityAuditSearchResponse = new EntityAuditSearchResponse();
        entityAuditSearchResponse.setAuditEntries(serviceToApiAuditEntities(auditEntities));

        return entityAuditSearchResponse;
    }
}
