package com.ekart.facp.audit.dal.exception;

import com.ekart.facp.audit.common.exceptions.ValidationException;

import static com.ekart.facp.audit.common.enums.ErrorCode.INVALID_DATA_ACCESS;

/**
 * Created by akshit.agarwal on 06/06/16.
 */
public class InvalidDataAccessException extends ValidationException {
    private static final long serialVersionUID = -1538138239541983285L;

    public InvalidDataAccessException(String tableName, String columnFamily, Throwable cause) {
        super("Invalid data access to datastore for tableName: " + tableName + " ,column: " + columnFamily,
                INVALID_DATA_ACCESS.name(), cause);
    }

    public InvalidDataAccessException(String message) {
        super(message, INVALID_DATA_ACCESS.name());
    }
}
