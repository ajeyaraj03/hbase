package com.ekart.facp.audit.dal.util;

import com.google.common.hash.Hashing;
import com.google.common.primitives.Bytes;
import com.google.common.primitives.Longs;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Created by akshit.agarwal on 07/06/16.
 */
@ParametersAreNonnullByDefault
@ThreadSafe
public class HbaseKeyGenerator {

    private static final String DELIMITER = "//";

    /**
     * This method generates rowKey for storing jn Hbase
     * Format of rowKey: RandomHash//EntityName//EntityId//Timestamp//EntityVersion//RandomBytes
     * whereby '//' is a delimeter
     * It is prefixed by 'RandomHash' to prevent hbase hotspotting, this is generated on entityId
     * It is suffixed by 'RandomBytes' to prevent overwritting of duplicate row in hbase, this is purely random.
     *
     * @param entityName
     * @param entityId
     * @param timestamp
     * @param entityVersion
     *
     * @return : rowKeyBytes
     */

    public byte[] encodeRowKey(String entityName, String entityId, long timestamp, long entityVersion) {
        byte[] versionByteArray = Longs.toByteArray(entityVersion);
        byte[] delimiterByteArray = convertStringToBytes(DELIMITER);
        return Bytes.concat(
                generatePrefixedRowKey(entityName, entityId, timestamp),
                versionByteArray, delimiterByteArray, uuidBytes()
        );
    }

    public byte[] generatePrefixedRowKey(String entityName, String entityId, long timestamp) {
        byte[] randomHashByte4 = generateHash(entityId);
        byte[] entityNameBytes = convertStringToBytes(entityName);
        byte[] entityIdBytes = convertStringToBytes(entityId);
        byte[] timestampBytes = Longs.toByteArray(timestamp);
        byte[] delimiterBytes = convertStringToBytes(DELIMITER);
        return Bytes.concat(
                randomHashByte4, delimiterBytes,
                entityNameBytes, delimiterBytes,
                entityIdBytes, delimiterBytes,
                timestampBytes, delimiterBytes
        );
    }

    public byte[] convertStringToBytes(String str) {
        return str.getBytes(getCharset());
    }

    private byte[] generateHash(String str) {
        return Hashing.murmur3_32().hashString(str, getCharset()).asBytes();
    }

    private Charset getCharset() {
        return StandardCharsets.UTF_8;
    }

    private byte[] uuidBytes() {
        UUID uuid = UUID.randomUUID();
        return Bytes.concat(
                Longs.toByteArray(uuid.getMostSignificantBits()),
                Longs.toByteArray(uuid.getLeastSignificantBits())
        );
    }
}

