package com.ekart.facp.audit.apis.config.spring;

import com.ekart.facp.audit.service.AuditService;
import com.ekart.facp.audit.service.AuditServiceImpl;
import com.ekart.facp.audit.service.mapper.ServiceRepositoryDtoMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.inject.Inject;

/**
 * Created by akshit.agarwal on 23/05/16.
 */
@Configuration
@Import({RepositoryConfig.class})
public class BusinessServiceConfig {

    @Inject
    private RepositoryConfig repositoryConfig;

    @Inject
    private ServiceRepositoryDtoMapper mapper;

    @Bean
    public AuditService auditService() {
        return new AuditServiceImpl(repositoryConfig.auditEntityRepository(), mapper);
    }
}
