package com.ekart.facp.audit.dal.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import java.util.Collections;
import java.util.Map;

import static com.ekart.facp.audit.dal.util.Constants.DATA_ATTRIBUTES_KEY_NAME;

/**
 * Created by akshit.agarwal on 18/07/16.
 */
@Immutable
@ParametersAreNonnullByDefault
public class AuditEntity {
    private final String entityName;
    private final String entityId;
    private final long entityVersion;
    private final String entityType;
    private final String createdByActor;
    private final long createdAtEpoch;
    private final String updatedByActor;
    private final long updatedAtEpoch;
    private final String updatedByProcessId;
    private final String facilityId;

    // Needed this so as to avoid this field during serialization
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private final Map<String, Object> dataAttributes;

    // Needed for deserialization
    @JsonCreator
    public AuditEntity(@JsonProperty("entityName") String entityName,
                       @JsonProperty("entityId") String entityId,
                       @JsonProperty("entityVersion") long entityVersion,
                       @JsonProperty("entityType") String entityType,
                       @JsonProperty("createdByActor") String createdByActor,
                       @JsonProperty("createdAtEpoch") long createdAtEpoch,
                       @JsonProperty("updatedByActor") String updatedByActor,
                       @JsonProperty("updatedAtEpoch") long updatedAtEpoch,
                       @JsonProperty("updatedByProcessId") String updatedByProcessId,
                       @JsonProperty("facilityId") String facilityId,
                       @JsonProperty(DATA_ATTRIBUTES_KEY_NAME) Map<String, Object> dataAttributes) {
        this.entityName = entityName;
        this.entityId = entityId;
        this.entityVersion = entityVersion;
        this.entityType = entityType;
        this.createdByActor = createdByActor;
        this.createdAtEpoch = createdAtEpoch;
        this.updatedByActor = updatedByActor;
        this.updatedAtEpoch = updatedAtEpoch;
        this.updatedByProcessId = updatedByProcessId;
        this.facilityId = facilityId;
        // Not using Guava's ImmutableMap as dataAttributes might contain null values, not supported by library
        this.dataAttributes = Collections.unmodifiableMap(dataAttributes);
    }

    public String getEntityName() {
        return entityName;
    }

    public String getEntityId() {
        return entityId;
    }

    public long getEntityVersion() {
        return entityVersion;
    }

    public String getEntityType() {
        return entityType;
    }

    public String getCreatedByActor() {
        return createdByActor;
    }

    public long getCreatedAtEpoch() {
        return createdAtEpoch;
    }

    public String getUpdatedByActor() {
        return updatedByActor;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    public String getUpdatedByProcessId() {
        return updatedByProcessId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public Map<String, Object> getDataAttributes() {
        return dataAttributes;
    }

    @Override
    public String toString() {
        return "AuditEntity{"
                + "entityName='" + entityName + '\''
                + ", entityId='" + entityId + '\''
                + ", entityVersion=" + entityVersion
                + ", entityType='" + entityType + '\''
                + ", createdByActor='" + createdByActor + '\''
                + ", createdAtEpoch=" + createdAtEpoch
                + ", updatedByActor='" + updatedByActor + '\''
                + ", updatedAtEpoch=" + updatedAtEpoch
                + ", updatedByProcessId='" + updatedByProcessId + '\''
                + ", facilityId='" + facilityId + '\''
                + ", dataAttributes=" + dataAttributes
                + '}';
    }
}
