package com.ekart.facp.audit.dal.ddl;

import com.ekart.facp.audit.common.util.TenantContext;

import java.util.List;

/**
 * Created by akshit.agarwal on 01/06/16.
 */
public interface AuditDDLUtility {
    void create(TenantContext tenantContext, String tableName, List<String> columnFamilyNames);
}
