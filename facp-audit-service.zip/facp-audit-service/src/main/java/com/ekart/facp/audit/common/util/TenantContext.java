package com.ekart.facp.audit.common.util;

/**
 * Created by akshit.agarwal on 01/06/16.
 *
 * PlaceHolder for future Tenant information.
 */
public class TenantContext {

    /**
     * Update the equals and hashcode method once we have one or more fields introduced
     * in this class.
     */
    @Override
    public boolean equals(Object o) {
        return this == o || !(o == null || getClass() != o.getClass());
    }

    @Override
    public int hashCode() {
        return 0;
    }
}
