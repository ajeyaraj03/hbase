package com.ekart.facp.audit.apis.config.spring;

import com.ekart.facp.audit.apis.controller.AuditController;
import com.ekart.facp.audit.apis.controller.HealthCheckController;
import com.ekart.facp.audit.apis.mapper.ApiServiceDtoMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.inject.Inject;

@Configuration
@ComponentScan({"com.ekart.facp.audit.service.mapper"})
@Import({JettyConfig.class, HealthCheckConfig.class, BusinessServiceConfig.class})
public class ApplicationConfig {

    // Reference:
    // http://docs.spring.io/spring-javaconfig/docs/1.0.0.M4/reference/html/ch04s02.html
    @Inject
    private HealthCheckConfig healthCheckConfig;

    @Inject
    private JettyConfig jettyConfig;

    @Inject
    private BusinessServiceConfig businessServiceConfig;

    @Inject
    private ApiServiceDtoMapper mapper;

    @Bean
    public HealthCheckController healthCheckController() {

        return new HealthCheckController(healthCheckConfig.masterHealthCheck(), jettyConfig.elbStatisticsCollector());
    }

    @Bean
    public AuditController auditController() {
        return new AuditController(businessServiceConfig.auditService(), mapper);
    }
}
