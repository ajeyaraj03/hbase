package com.ekart.facp.audit.service.dtos;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;

/**
 * Created by akshit.agarwal on 01/07/16.
 */
@Immutable
@ParametersAreNonnullByDefault
public class AuditResponse {
    private final String entityName;
    private final String entityId;
    private final long entityVersion;
    private final long updatedAtEpoch;
    private final boolean success;
    private final String message;

    public AuditResponse(String entityName, String entityId, long entityVersion, long updatedAtEpoch,
                         boolean success, String message) {
        this.entityName = entityName;
        this.entityId = entityId;
        this.updatedAtEpoch = updatedAtEpoch;
        this.entityVersion = entityVersion;
        this.success = success;
        this.message = message;
    }

    public String getEntityName() {
        return entityName;
    }

    public String getEntityId() {
        return entityId;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    public long getEntityVersion() {
        return entityVersion;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return "AuditResponse{"
                + "entityName='" + entityName + '\''
                + ", entityId='" + entityId + '\''
                + ", entityVersion=" + entityVersion
                + ", updatedAtEpoch=" + updatedAtEpoch
                + ", success=" + success
                + ", message='" + message + '\''
                + '}';
    }
}
