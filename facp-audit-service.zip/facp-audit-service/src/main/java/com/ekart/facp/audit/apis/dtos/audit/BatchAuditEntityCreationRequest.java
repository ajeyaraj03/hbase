package com.ekart.facp.audit.apis.dtos.audit;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.util.List;

import static com.ekart.facp.audit.common.util.Constraints.AUDIT_ENTITY_LIST_MAX_SIZE;
import static com.ekart.facp.audit.common.util.Constraints.AUDIT_ENTITY_LIST_MIN_SIZE;

/**
 * Created by akshit.agarwal on 18/07/16.
 */
@ApiModel(description = "Request to create audit entries in the datastore for mentioned entities")
public class BatchAuditEntityCreationRequest {
    @Valid
    @ApiModelProperty(name = "audit_entries", value = "List of audit entries")
    @JsonProperty(value = "audit_entries", required = true)
    @NotEmpty(message = "{batchEntityAuditCreation.auditEntities.notempty}")
    @Size(min = AUDIT_ENTITY_LIST_MIN_SIZE, max = AUDIT_ENTITY_LIST_MAX_SIZE)
    private List<AuditEntity> auditEntities;

    public List<AuditEntity> getAuditEntities() {
        return auditEntities;
    }

    public void setAuditEntities(List<AuditEntity> auditEntities) {
        this.auditEntities = auditEntities;
    }

    @Override
    public String toString() {
        return "BatchAuditEntityCreationRequest{"
                + "auditEntities=" + auditEntities
                + '}';
    }
}
