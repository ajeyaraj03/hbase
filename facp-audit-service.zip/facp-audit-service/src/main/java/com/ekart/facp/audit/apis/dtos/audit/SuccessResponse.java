package com.ekart.facp.audit.apis.dtos.audit;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Created by akshit.agarwal on 29/05/16.
 */
@ApiModel(value = "Success response", description = "Response stating whether request is successful or not ")
public class SuccessResponse {

    @ApiModelProperty(name = "success", value = "boolean value indicating success is true/false")
    @JsonProperty(value = "success")
    private boolean success = true;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    @Override
    public String toString() {
        return "SuccessResponse{"
                + "success=" + success
                + '}';
    }
}
