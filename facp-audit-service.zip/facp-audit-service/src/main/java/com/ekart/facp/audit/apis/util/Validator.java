package com.ekart.facp.audit.apis.util;

import com.ekart.facp.audit.apis.exception.InvalidInputException;

/**
 * Created by akshit.agarwal on 30/05/16.
 */
public final class Validator {

    private Validator() {
    }

    public static void validatePositiveLong(long longValue, String name) {
        if (longValue < 1) {
            throw new InvalidInputException(name + " should be >= 1");
        }
    }

    public static void validateFromAndToTimestamp(long startTimestamp, long endTimestamp) {
        if (endTimestamp < startTimestamp) {
            throw new InvalidInputException("EndTimestamp " + endTimestamp + " should be >= than startTimestamp "
                    + startTimestamp);
        }
    }
}
