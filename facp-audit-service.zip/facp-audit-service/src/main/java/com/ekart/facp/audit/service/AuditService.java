package com.ekart.facp.audit.service;

import com.ekart.facp.audit.common.util.TenantContext;
import com.ekart.facp.audit.service.dtos.AuditEntity;
import com.ekart.facp.audit.service.dtos.AuditResponse;
import com.ekart.facp.audit.service.dtos.BatchAuditEntityCreationRequest;

import java.util.List;

/**
 * Created by akshit.agarwal on 27/05/16.
 */

public interface AuditService {
    List<AuditResponse> bulkCreate(TenantContext tenantContext, BatchAuditEntityCreationRequest request);

    List<AuditEntity> findEntries(TenantContext tenantContext, String entityName, String entityId,
                                  long startTimestamp, long endTimestamp);
}
