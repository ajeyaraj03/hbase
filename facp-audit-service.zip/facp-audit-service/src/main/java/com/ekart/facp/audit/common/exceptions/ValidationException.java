package com.ekart.facp.audit.common.exceptions;

/**
 * Created by akshit.agarwal on 07/07/16.
 */
public abstract class ValidationException extends BaseRuntimeException {
    private static final long serialVersionUID = -3974175123412894944L;

    protected ValidationException(String message, String errorCode, Object response) {
        super(message, errorCode, response);
    }

    protected ValidationException(String message, String errorCode) {
        super(message, errorCode);
    }

    protected ValidationException(String message, String errorCode, Throwable cause) {
        super(message, errorCode, cause);
    }

    protected ValidationException(String message, String errorCode, Object response, Throwable cause) {
        super(message, errorCode, response, cause);
    }
}
