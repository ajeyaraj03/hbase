package com.ekart.facp.audit.service.util;

/**
 * Created by akshit.agarwal on 25/07/16.
 */
public final class Constants {
    public static final String SUCCESS_CREATE_AUDIT_MESSAGE = "Successfully Audit Created.";

    private Constants() {
    }
}
