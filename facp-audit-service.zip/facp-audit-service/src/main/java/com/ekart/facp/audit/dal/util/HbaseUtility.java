package com.ekart.facp.audit.dal.util;

import com.ekart.facp.audit.dal.dtos.AuditEntity;
import com.ekart.facp.audit.dal.exception.DeserializationException;
import com.ekart.facp.audit.dal.exception.DuplicateAttributeException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import static com.ekart.facp.audit.dal.util.Constants.DATA_ATTRIBUTES_KEY_NAME;
import static com.ekart.facp.audit.dal.util.Constants.DATA_ATTRIBUTES_PREFIX;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by akshit.agarwal on 29/07/16.
 * <p>
 * This class does conversion from and to AuditEntity,
 * created separate utility mainly to improve code testability which otherwise was not possible
 */
@ThreadSafe
@ParametersAreNonnullByDefault
public class HbaseUtility {
    private static final Logger LOGGER = LoggerFactory.getLogger(HbaseUtility.class);

    private final ObjectMapper mapper;

    public HbaseUtility(ObjectMapper mapper) {
        this.mapper = checkNotNull(mapper);
    }

    /**
     * This method takes in Hbase Row Result and converts it AuditEntity DTO
     * It takes into account replacing of prefixed key while deserializing,
     * which was prefixed during conversion of AuditEntity into Map for hbase record insertion.
     */
    public AuditEntity convertResultToAuditEntity(Result result, String tableName, String columnFamily) {
        List<Cell> rowCells = result.listCells();
        Map<String, Object> auditEntityAttributes = Maps.newHashMapWithExpectedSize(rowCells.size());
        Map<String, Object> dataAttributes = Maps.newHashMapWithExpectedSize(rowCells.size());

        rowCells.forEach(cell -> {
            String qualifier = Bytes.toString(CellUtil.cloneQualifier(cell));
            Object value;
            try {
                value = mapper.readValue(CellUtil.cloneValue(cell), Object.class);
            } catch (IOException e) {
                LOGGER.error("Error while deserializing columnValue for tablename: {}, columnFamily: {}, "
                        + "qualifier: {}, ", tableName, columnFamily, qualifier, e);

                throw new DeserializationException(String.join(":", columnFamily, qualifier), e);
            }

            if (qualifier.startsWith(DATA_ATTRIBUTES_PREFIX)) {
                dataAttributes.put(qualifier.replace(DATA_ATTRIBUTES_PREFIX, ""), value);
            } else {
                auditEntityAttributes.put(qualifier, value);
            }
        });
        auditEntityAttributes.put(DATA_ATTRIBUTES_KEY_NAME, dataAttributes);
        return getAuditEntity(auditEntityAttributes);
    }

    /**
     * This method is use to serialize or convert a DTO AuditEntity to HashMap so that
     * it can be stored as key-value pairs in hbase.
     * Prefixing of dataAttributes is required to over overriding of keys b/n mandatory and data attributes
     * throws exceptions when overriding of keys happens b/n mandatory Attributes and data attributes
     */
    @SuppressWarnings("unchecked")
    public Map<String, Object> convertAuditEntityToMap(AuditEntity auditEntity) {
        Map<String, Object> entityAttributes = mapper.convertValue(auditEntity, Map.class);
        Map<String, Object> attributes = Maps.newHashMapWithExpectedSize(entityAttributes.size()
                + auditEntity.getDataAttributes().size());

        auditEntity.getDataAttributes().forEach((k, v) -> {
            String prefixedKey = String.join("", DATA_ATTRIBUTES_PREFIX, k);
            if (entityAttributes.containsKey(prefixedKey)) {
                throw new DuplicateAttributeException(auditEntity, prefixedKey);
            } else {
                attributes.put(prefixedKey, v);
            }
        });

        attributes.putAll(entityAttributes);
        return attributes;
    }

    /**
     * This method is required to deserialize data stored in hbase in form of HashMap to specified DTO.
     * Uses Jackson Object Mapper for deserialization.
     */
    private AuditEntity getAuditEntity(Map<String, Object> auditAttributes) {
        return mapper.convertValue(auditAttributes, AuditEntity.class);
    }
}
