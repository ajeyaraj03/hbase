package com.ekart.facp.audit.dal;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.audit.common.util.TenantContext;
import com.ekart.facp.audit.dal.dtos.AuditEntity;
import com.ekart.facp.audit.dal.exception.InvalidDataAccessException;
import com.ekart.facp.audit.dal.exception.SerializationException;
import com.ekart.facp.audit.dal.util.HbaseKeyGenerator;
import com.ekart.facp.audit.dal.util.HbaseUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Scan;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.hadoop.hbase.HbaseSystemException;
import org.springframework.data.hadoop.hbase.HbaseTemplate;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.ekart.facp.audit.dal.util.Constants.DEFAULT_COLUMN_FAMILY_NAME;
import static com.ekart.facp.audit.dal.util.Constants.DEFAULT_HBASE_TABLE_NAME;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by akshit.agarwal on 27/05/16.
 */
@ParametersAreNonnullByDefault
@ThreadSafe
public class HbaseRepositoryImpl implements AuditEntityRepository {
    private static final Logger LOGGER = LoggerFactory.getLogger(HbaseRepositoryImpl.class);

    private final HbaseTemplate hbaseTemplate;
    private final ObjectMapper mapper;
    private final HbaseKeyGenerator keyGenerator;
    private final HbaseUtility hbaseUtility;

    public HbaseRepositoryImpl(HbaseTemplate hbaseTemplate, ObjectMapper mapper, HbaseKeyGenerator keyGenerator,
                               HbaseUtility hbaseUtility) {
        this.hbaseTemplate = checkNotNull(hbaseTemplate);
        this.mapper = checkNotNull(mapper);
        this.keyGenerator = checkNotNull(keyGenerator);
        this.hbaseUtility = checkNotNull(hbaseUtility);
    }

    /**
     * This method is use to save/insert given record in Hbase for the specified tablename and columnFamily
     *
     * @param tenantContext : TenantContext for any tenant rules
     * @param auditEntities : List of audit entity records
     * @return
     */
    @Timed
    @ExceptionMetered
    @Override
    public void save(TenantContext tenantContext, List<AuditEntity> auditEntities) {

        List<Put> puts = prepareAuditData(auditEntities);

        try {
            put(puts);
        } catch (HbaseSystemException e) {
            LOGGER.error("Error while storing data in Hbase for tablename: {}, columnFamily: {}, auditEntities: {}",
                    DEFAULT_HBASE_TABLE_NAME, DEFAULT_COLUMN_FAMILY_NAME, auditEntities, e);

            throw new InvalidDataAccessException(DEFAULT_HBASE_TABLE_NAME, DEFAULT_COLUMN_FAMILY_NAME, e);
        }
    }

    private List<Put> prepareAuditData(List<AuditEntity> auditEntities) {

        return auditEntities.stream().map(auditEntity -> {
            byte[] encodedRowKey = keyGenerator.encodeRowKey(
                    auditEntity.getEntityName(),
                    auditEntity.getEntityId(),
                    auditEntity.getUpdatedAtEpoch(),
                    auditEntity.getEntityVersion()
            );

            Put put = new Put(encodedRowKey);
            byte[] columnFamilyBytes = keyGenerator.convertStringToBytes(DEFAULT_COLUMN_FAMILY_NAME);

            hbaseUtility.convertAuditEntityToMap(auditEntity).forEach((key, value) -> {

                try {
                    byte[] valueBytes = mapper.writeValueAsBytes(value);
                    put.addColumn(columnFamilyBytes, keyGenerator.convertStringToBytes(key), valueBytes);
                } catch (JsonProcessingException e) {
                    LOGGER.error("Error while serializing object for tablename: {},"
                                    + " columnFamily: {}, auditEntity: {}"
                                    + ", key: {}, value: {}",
                            DEFAULT_HBASE_TABLE_NAME, DEFAULT_COLUMN_FAMILY_NAME, auditEntity, key, value, e);

                    throw new SerializationException(String.join(":", DEFAULT_COLUMN_FAMILY_NAME, key),
                            value, e);
                }
            });
            return put;
        }).collect(Collectors.toList());

    }

    /**
     * This method is use for range scans on the table. It will scan and return the rows
     * from start row key (inclusive) till the stop row key (exclusive)
     *
     * @param tenantContext  : TenantContext for any tenant rules
     * @param entityName     : EntityName on which we need to search
     * @param entityId       : EntityId for which we need to search
     * @param startTimestamp : Timestamp to start the search from (inclusive).
     * @param endTimestamp   : Timestamp till which scan happens (inclusive)
     * @return List of records wraped as AuditEntity object
     */
    @Timed
    @ExceptionMetered
    @Override
    public List<AuditEntity> findbyIdAndTimeRange(TenantContext tenantContext, String entityName, String entityId,
                                                  long startTimestamp, long endTimestamp) {

        // We are adding +1 to have inclusion of endTimestamp because hbase does exclusion on stopkey
        long stopRowTimestamp = endTimestamp + 1;
        byte[] startRowKey = keyGenerator.generatePrefixedRowKey(entityName, entityId, startTimestamp);

        byte[] stopRowKey = keyGenerator.generatePrefixedRowKey(entityName, entityId, stopRowTimestamp);

        Scan scan = new Scan(startRowKey, stopRowKey);
        scan.addFamily(keyGenerator.convertStringToBytes(DEFAULT_COLUMN_FAMILY_NAME));

        try {
            return hbaseTemplate.find(DEFAULT_HBASE_TABLE_NAME, scan, results -> {
                return StreamSupport.stream(results.spliterator(), false)
                        .map(result -> hbaseUtility.convertResultToAuditEntity(result, DEFAULT_HBASE_TABLE_NAME,
                                DEFAULT_COLUMN_FAMILY_NAME))
                        .collect(Collectors.toList());
            });
        } catch (HbaseSystemException e) {
            LOGGER.error("Error while fetching data from Hbase for tablename: {}, entityName: {}, entityId: {},"
                            + "startTimestamp: {}, endTimestamp: {}", DEFAULT_HBASE_TABLE_NAME, entityName, entityId,
                    startTimestamp, stopRowTimestamp, e);

            throw new InvalidDataAccessException(DEFAULT_HBASE_TABLE_NAME, DEFAULT_COLUMN_FAMILY_NAME, e);
        }
    }

    /**
     * Not using HbaseTemplate put APi {@link HbaseTemplate#put(String, String, String, String, byte[])}, as
     * it takes string parameters, converts it to byte array according to specified encoding. This might conflict
     * with the byte encoding of this repo. So using our method put with takes in byte[]
     */
    private void put(List<Put> puts) {
        hbaseTemplate.execute(DEFAULT_HBASE_TABLE_NAME, htable -> {
            htable.put(puts);
            return null;
        });
    }
}
