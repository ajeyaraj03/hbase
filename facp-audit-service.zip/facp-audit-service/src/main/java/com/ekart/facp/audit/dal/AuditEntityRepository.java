package com.ekart.facp.audit.dal;

import com.ekart.facp.audit.common.util.TenantContext;
import com.ekart.facp.audit.dal.dtos.AuditEntity;

import java.util.List;

/**
 * Created by akshit.agarwal on 25/05/16.
 */
public interface AuditEntityRepository {
    void save(TenantContext tenantContext, List<AuditEntity> auditEntities);

    List<AuditEntity> findbyIdAndTimeRange(TenantContext tenantContext, String entityName, String entityId,
                                           long startTimestamp, long endTimestamp);
}
