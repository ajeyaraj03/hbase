package com.ekart.facp.audit.apis.dtos.audit;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Map;

/**
 * Created by akshit.agarwal on 12/07/16.
 */
@ApiModel
public class AuditEntity {

    @NotNull(message = "{entityAuditCreation.entityName.notnull}")
    @ApiModelProperty(name = "entity_name", required = true, example = "item", value = "Name of entity")
    @JsonProperty(value = "entity_name", required = true)
    private String entityName;

    @NotNull(message = "{entityAuditCreation.entityId.notnull}")
    @ApiModelProperty(name = "entity_id", required = true, example = "100", value = "Id of entity")
    @JsonProperty(value = "entity_id", required = true)
    private String entityId;

    @Min(value = 1, message = "{entityAuditCreation.entityVersion.valid}")
    @ApiModelProperty(name = "entity_version", required = true, example = "1", value = "Version of entity")
    @JsonProperty(value = "entity_version", required = true)
    private long entityVersion;

    @NotNull(message = "{entityAuditCreation.entityType.notnull}")
    @ApiModelProperty(name = "entity_type", required = true, example = "shipment", value = "Type of entity")
    @JsonProperty(value = "entity_type", required = true)
    private String entityType;

    @NotNull(message = "{entityAuditCreation.createdByActor.notnull}")
    @ApiModelProperty(name = "created_by_actor", required = true, example = "john", value = "Entity created by")
    @JsonProperty(value = "created_by_actor", required = true)
    private String createdByActor;

    @Min(value = 1, message = "{entityAuditCreation.createdAtEpoch.valid}")
    @ApiModelProperty(name = "created_at_epoch", required = true, example = "876543765",
            value = "Time of entity creation")
    @JsonProperty(value = "created_at_epoch", required = true)
    private long createdAtEpoch;

    @NotNull(message = "{entityAuditCreation.updatedByActor.notnull}")
    @ApiModelProperty(name = "updated_by_actor", required = true, example = "john", value = "Entity last updated by")
    @JsonProperty(value = "updated_by_actor", required = true)
    private String updatedByActor;

    @Min(value = 1, message = "{entityAuditCreation.updatedAtEpoch.valid}")
    @ApiModelProperty(name = "updated_at_epoch", required = true, example = "876543765",
            value = "Time of entity updation")
    @JsonProperty(value = "updated_at_epoch", required = true)
    private long updatedAtEpoch;

    @NotNull(message = "{entityAuditCreation.updatedByProcessId.notnull}")
    @ApiModelProperty(name = "updated_by_process_id", required = true, example = "dispatch_process_id",
            value = "Process id due to which entity was updated")
    @JsonProperty(value = "updated_by_process_id", required = true)
    private String updatedByProcessId;

    @NotNull(message = "{entityAuditCreation.facilityId.notnull}")
    @ApiModelProperty(name = "facility_id", required = true, example = "blr_wfld",
            value = "facility id entity belongs to")
    @JsonProperty(value = "facility_id", required = true)
    private String facilityId;

    @NotEmpty(message = "{entityAuditCreation.dataAttributes.notnull}")
    @ApiModelProperty(name = "attributes", required = true, value = "Entity attributes to be audited")
    @JsonProperty(value = "attributes", required = true)
    private Map<String, Object> dataAttributes;

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public long getEntityVersion() {
        return entityVersion;
    }

    public void setEntityVersion(long entityVersion) {
        this.entityVersion = entityVersion;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getCreatedByActor() {
        return createdByActor;
    }

    public void setCreatedByActor(String createdByActor) {
        this.createdByActor = createdByActor;
    }

    public long getCreatedAtEpoch() {
        return createdAtEpoch;
    }

    public void setCreatedAtEpoch(long createdAtEpoch) {
        this.createdAtEpoch = createdAtEpoch;
    }

    public String getUpdatedByActor() {
        return updatedByActor;
    }

    public void setUpdatedByActor(String updatedByActor) {
        this.updatedByActor = updatedByActor;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    public void setUpdatedAtEpoch(long updatedAtEpoch) {
        this.updatedAtEpoch = updatedAtEpoch;
    }

    public String getUpdatedByProcessId() {
        return updatedByProcessId;
    }

    public void setUpdatedByProcessId(String updatedByProcessId) {
        this.updatedByProcessId = updatedByProcessId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public Map<String, Object> getDataAttributes() {
        return dataAttributes;
    }

    public void setDataAttributes(Map<String, Object> dataAttributes) {
        this.dataAttributes = dataAttributes;
    }

    @Override
    public String toString() {
        return "AuditEntity{"
                + "entityName='" + entityName + '\''
                + ", entityId='" + entityId + '\''
                + ", entityVersion=" + entityVersion
                + ", entityType='" + entityType + '\''
                + ", createdByActor='" + createdByActor + '\''
                + ", createdAtEpoch=" + createdAtEpoch
                + ", updatedByActor='" + updatedByActor + '\''
                + ", updatedAtEpoch=" + updatedAtEpoch
                + ", updatedByProcessId='" + updatedByProcessId + '\''
                + ", facilityId='" + facilityId + '\''
                + ", dataAttributes=" + dataAttributes
                + '}';
    }
}
