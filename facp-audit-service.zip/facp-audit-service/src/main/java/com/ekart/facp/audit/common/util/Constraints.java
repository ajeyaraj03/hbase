package com.ekart.facp.audit.common.util;

/**
 * Created by akshit.agarwal on 20/07/16.
 */
public final class Constraints {

    private Constraints() {
    }

    public static final int AUDIT_ENTITY_LIST_MIN_SIZE = 1;
    public static final int AUDIT_ENTITY_LIST_MAX_SIZE = 5000;
}
