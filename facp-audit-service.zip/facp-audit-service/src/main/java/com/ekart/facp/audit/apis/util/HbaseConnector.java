package com.ekart.facp.audit.apis.util;

import com.ekart.facp.audit.apis.exception.HbaseConnectionException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.shaded.com.google.protobuf.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.hadoop.hbase.HbaseTemplate;

import java.io.IOException;

import static com.google.common.base.Preconditions.checkNotNull;


/**
 * Created by akshit.agarwal on 27/06/16.
 */
public class HbaseConnector {
    private static final Logger LOGGER = LoggerFactory.getLogger(HbaseConnector.class);
    private final HbaseConfigUtil hbaseConfigUtil;

    public HbaseConnector(HbaseConfigUtil hbaseConfigUtil) {
        this.hbaseConfigUtil = checkNotNull(hbaseConfigUtil);
    }

    public HBaseAdmin getAdmin() {
        Configuration hbaseConfig = hbaseConfigUtil.getHbaseConfig();
        try {
            Connection connection = ConnectionFactory.createConnection(hbaseConfig);
            HBaseAdmin admin = (HBaseAdmin) connection.getAdmin();
            admin.checkHBaseAvailable(hbaseConfig);
            return admin;
        } catch (IOException | ServiceException e) {
            LOGGER.error("Error while connecting to hbase server", e);
            throw new HbaseConnectionException(hbaseConfigUtil.toString(), e);
        }
    }

    public HbaseTemplate hbaseTemplate() {
        HbaseTemplate hbaseTemplate = new HbaseTemplate(hbaseConfigUtil.getHbaseConfig());
        /*Setting this variable to avoid flush in each put, flush will be called
         once release table happens in the template */
        hbaseTemplate.setAutoFlush(false);
        return hbaseTemplate;
    }
}
