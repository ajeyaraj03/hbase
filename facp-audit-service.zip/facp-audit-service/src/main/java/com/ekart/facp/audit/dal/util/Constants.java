package com.ekart.facp.audit.dal.util;

/**
 * Created by akshit.agarwal on 28/05/16.
 */
public final class Constants {
    public static final String DEFAULT_COLUMN_FAMILY_NAME = "cf";
    public static final String DATA_ATTRIBUTES_PREFIX = "data.";
    public static final String DEFAULT_HBASE_TABLE_NAME = "AUDIT_DATA";
    public static final String DATA_ATTRIBUTES_KEY_NAME = "dataAttributes";

    private Constants() {
    }
}
