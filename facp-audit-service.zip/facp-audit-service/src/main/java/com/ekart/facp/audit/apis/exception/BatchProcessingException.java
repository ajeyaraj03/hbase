package com.ekart.facp.audit.apis.exception;

import com.ekart.facp.audit.common.exceptions.ValidationException;

import static com.ekart.facp.audit.common.enums.ErrorCode.BATCH_PROCESSING_FAILED;

/**
 * Created by akshit.agarwal on 07/07/16.
 */
public class BatchProcessingException extends ValidationException {
    private static final long serialVersionUID = 7652667516782745129L;

    public BatchProcessingException(String message, Object response) {
        super(message, BATCH_PROCESSING_FAILED.name(), response);
    }
}
