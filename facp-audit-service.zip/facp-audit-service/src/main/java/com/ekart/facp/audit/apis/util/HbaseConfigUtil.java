package com.ekart.facp.audit.apis.util;

import com.ekart.facp.audit.apis.dtos.audit.HbaseTableConfig;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.springframework.beans.factory.annotation.Value;

/**
 * Created by akshit.agarwal on 22/06/16.
 */
public class HbaseConfigUtil {
    private static final String HBASE_ZOOKEEPER_QUORUM = "hbase.zookeeper.quorum";
    private static final String HBASE_ZOOKEEPER_CLIENTPORT = "hbase.zookeeper.property.clientPort";
    private static final String ZOOKEEPER_RECOVERY_RETRY = "zookeeper.recovery.retry";
    private static final String ZOOKEEPER_ZNODE_PARENT = "zookeeper.znode.parent";
    private static final String HBASE_CLIENT_RETRIES = "hbase.client.retries.number";
    private static final String HBASE_WRITE_BUFFER = "hbase.client.write.buffer";
    private static final String HBASE_MASTER = "hbase.master";
    private static final String TIMEOUT = "timeout";

    @Value("${hbase.serverConfig.zookeeper.quorum}")
    private String hbaseZookeeperQuorum;

    @Value("${hbase.serverConfig.zookeeper.clientPort}")
    private int hbaseZookeeperClientPort;

    @Value("${hbase.serverConfig.zookeeper.recovery.retry}")
    private int hbaseZookeeperRecoveryRetry;

    @Value("${hbase.serverConfig.zookeeper.znode.parent}")
    private String hbaseZookeeperZnodeParent;

    @Value("${hbase.serverConfig.client.retries.number}")
    private int hbaseClientRetries;

    @Value("${hbase.serverConfig.master}")
    private String hbaseMaster;

    @Value("${hbase.serverConfig.timeout}")
    private int hbaseTimeout;

    @Value("${hbase.tableConfig.regionReplication}")
    private int hbaseRegionReplication;

    @Value("${hbase.serverConfig.client.write.buffer}")
    private int hbaseWriteBuffer;

    public Configuration getHbaseConfig() {
        Configuration hbaseConfig = HBaseConfiguration.create();
        hbaseConfig.set(HBASE_ZOOKEEPER_QUORUM, hbaseZookeeperQuorum);
        hbaseConfig.set(ZOOKEEPER_ZNODE_PARENT, hbaseZookeeperZnodeParent);
        hbaseConfig.setInt(HBASE_ZOOKEEPER_CLIENTPORT, hbaseZookeeperClientPort);
        hbaseConfig.setInt(ZOOKEEPER_RECOVERY_RETRY, hbaseZookeeperRecoveryRetry);
        hbaseConfig.set(HBASE_MASTER, hbaseMaster);
        hbaseConfig.setInt(TIMEOUT, hbaseTimeout);
        hbaseConfig.setInt(HBASE_CLIENT_RETRIES, hbaseClientRetries);
        //setting to 10MB
        hbaseConfig.setInt(HBASE_WRITE_BUFFER, hbaseWriteBuffer);
        return hbaseConfig;
    }

    public HbaseTableConfig getHbaseTableConfig() {
        return new HbaseTableConfig(hbaseRegionReplication);
    }

    @Override
    public String toString() {
        return "HbaseConfigUtil{"
                + HBASE_ZOOKEEPER_QUORUM + "='" + hbaseZookeeperQuorum + '\''
                + ", " + HBASE_ZOOKEEPER_CLIENTPORT + "='" + hbaseZookeeperClientPort
                + ", " + ZOOKEEPER_RECOVERY_RETRY + "='" + hbaseZookeeperRecoveryRetry
                + ", " + ZOOKEEPER_ZNODE_PARENT + "='" + hbaseZookeeperZnodeParent + '\''
                + ", " + HBASE_CLIENT_RETRIES + "='" + hbaseClientRetries
                + ", " + HBASE_MASTER + "='" + hbaseMaster + '\''
                + ", " + TIMEOUT + "='" + hbaseTimeout
                + '}';
    }
}
