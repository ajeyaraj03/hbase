package com.ekart.facp.audit.dal.exception;

import com.ekart.facp.audit.common.exceptions.ValidationException;

import static com.ekart.facp.audit.common.enums.ErrorCode.INVALID_DDL_SPECIFICATION;

/**
 * Created by akshit.agarwal on 01/06/16.
 */
public class InvalidDDLSpecificationException extends ValidationException {
    private static final long serialVersionUID = 7973432893568640764L;

    public InvalidDDLSpecificationException(String message, Throwable cause) {
        super(message, INVALID_DDL_SPECIFICATION.name(), cause);
    }
}
