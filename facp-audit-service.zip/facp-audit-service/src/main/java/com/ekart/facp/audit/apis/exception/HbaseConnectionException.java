package com.ekart.facp.audit.apis.exception;

import com.ekart.facp.audit.common.exceptions.BaseRuntimeException;

import static com.ekart.facp.audit.common.enums.ErrorCode.HBASE_CONNECTION_FAILED;

/**
 * Created by akshit.agarwal on 22/06/16.
 */
public class HbaseConnectionException extends BaseRuntimeException {
    private static final long serialVersionUID = 7288539266296695259L;

    public HbaseConnectionException(String config, Throwable cause) {
        super("Unable to connect to HBASE server. Connection configuration: " + config, HBASE_CONNECTION_FAILED.name(),
                cause);
    }
}
