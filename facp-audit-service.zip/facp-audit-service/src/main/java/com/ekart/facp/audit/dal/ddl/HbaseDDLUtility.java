package com.ekart.facp.audit.dal.ddl;

import com.ekart.facp.audit.apis.dtos.audit.HbaseTableConfig;
import com.ekart.facp.audit.common.util.TenantContext;
import com.ekart.facp.audit.dal.exception.InvalidDDLSpecificationException;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableExistsException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.io.IOException;
import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by akshit.agarwal on 01/06/16.
 */
@ThreadSafe
@ParametersAreNonnullByDefault
public class HbaseDDLUtility implements AuditDDLUtility {
    private static final Logger LOGGER = LoggerFactory.getLogger(HbaseDDLUtility.class);
    private static final int MAX_ROW_VERSIONS = 1;

    private final HBaseAdmin admin;
    private final HbaseTableConfig hbaseTableConfig;

    public HbaseDDLUtility(HBaseAdmin admin, HbaseTableConfig hbaseTableConfig) {
        this.admin = checkNotNull(admin);
        this.hbaseTableConfig = checkNotNull(hbaseTableConfig);
    }

    /**
     * This method is use to create table in the Hbase with the given create parameters/configuration.
     *
     * @param tenantContext : TenantContext for any tenant rules
     * @param tableName : Hbase TableName which keeps the record
     * @param columnFamilyNames : List of columnFamily names
     * @return tableName created
     */
    @Override
    public void create(TenantContext tenantContext, String tableName, List<String> columnFamilyNames) {
        try {
            TableName table = TableName.valueOf(tableName);
            HTableDescriptor tableDescriptor = new HTableDescriptor(table);

            //Setting table config variable from hbaseTableConfig
            tableDescriptor.setRegionReplication(hbaseTableConfig.getRegionReplication());
            columnFamilyNames.forEach((cf) -> setColumnFamilyConfig(cf, tableDescriptor));

            admin.createTable(tableDescriptor);
            LOGGER.info("Table Creation successful in HBase : {}", tableName);
        } catch (TableExistsException e) {
            LOGGER.error("TableName {} already exist", tableName, e);
            throw new InvalidDDLSpecificationException("TableName " + tableName + " already exists.", e);
        } catch (IOException e) {
            LOGGER.error("Error while table creation", e);
            throw new InvalidDDLSpecificationException("Failed to create table " + tableName, e);
        }
    }

    private void setColumnFamilyConfig(String columnFamily, HTableDescriptor tableDescriptor) {
        HColumnDescriptor columnDescriptor = new HColumnDescriptor(columnFamily);
        columnDescriptor.setMaxVersions(MAX_ROW_VERSIONS);
        tableDescriptor.addFamily(columnDescriptor);
    }
}
