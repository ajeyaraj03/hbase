package com.ekart.facp.audit.service;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.audit.common.exceptions.ValidationException;
import com.ekart.facp.audit.common.util.TenantContext;
import com.ekart.facp.audit.dal.AuditEntityRepository;
import com.ekart.facp.audit.service.dtos.AuditEntity;
import com.ekart.facp.audit.service.dtos.AuditResponse;
import com.ekart.facp.audit.service.dtos.BatchAuditEntityCreationRequest;
import com.ekart.facp.audit.service.mapper.ServiceRepositoryDtoMapper;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.util.List;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.ekart.facp.audit.service.util.Constants.SUCCESS_CREATE_AUDIT_MESSAGE;
import static com.ekart.facp.audit.common.util.Constraints.AUDIT_ENTITY_LIST_MAX_SIZE;

/**
 * Created by akshit.agarwal on 23/05/16.
 */

@Service
@ParametersAreNonnullByDefault
@ThreadSafe
public class AuditServiceImpl implements AuditService {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuditServiceImpl.class);

    private final AuditEntityRepository auditEntityRepository;
    private final ServiceRepositoryDtoMapper mapper;

    public AuditServiceImpl(AuditEntityRepository auditEntityRepository, ServiceRepositoryDtoMapper mapper) {
        this.auditEntityRepository = checkNotNull(auditEntityRepository);
        this.mapper = checkNotNull(mapper);
    }

    @Timed
    @ExceptionMetered
    @Override
    public List<AuditResponse> bulkCreate(TenantContext tenantContext, BatchAuditEntityCreationRequest request) {

        List<List<AuditEntity>> partionedAuditEntities = Lists.partition(request.getAuditEntities(),
                AUDIT_ENTITY_LIST_MAX_SIZE);

        List<List<AuditResponse>> reponses = partionedAuditEntities.stream().map(auditEntities -> {

            boolean success = true;
            String message = SUCCESS_CREATE_AUDIT_MESSAGE;
            try {
                auditEntityRepository.save(tenantContext, mapper.serviceToRepositoryAuditEntities(auditEntities));
                LOGGER.debug("Bulk Create | Successfully created Audit Entity: {}", auditEntities);
            } catch (ValidationException e) {
                LOGGER.warn("Bulk Create | Error creating Audit Entity: {}", auditEntities, e);
                success = false;
                message = e.getMessage();
            }

            return prepareAuditResponse(auditEntities, success, message);

        }).collect(Collectors.toList());

        return reponses.stream().flatMap(List::stream).collect(Collectors.toList());
    }

    private List<AuditResponse> prepareAuditResponse(List<AuditEntity> auditEntities, boolean success, String message) {

        return auditEntities.stream().map(auditEntity -> new AuditResponse(auditEntity.getEntityName(),
                auditEntity.getEntityId(), auditEntity.getEntityVersion(), auditEntity.getUpdatedAtEpoch(),
                success, message)).collect(Collectors.toList());
    }

    @Timed
    @ExceptionMetered
    @Override
    public List<AuditEntity> findEntries(TenantContext tenantContext, String entityName, String entityId,
                                         long startTimestamp, long endTimestamp) {

        return mapper.repositoryToServiceAuditEntities(
                auditEntityRepository.findbyIdAndTimeRange(tenantContext, entityName, entityId,
                        startTimestamp, endTimestamp)
        );
    }

}

