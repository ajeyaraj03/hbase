package com.ekart.facp.audit.service.dtos;

import com.google.common.collect.ImmutableList;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.Immutable;
import java.util.List;

/**
 * Created by akshit.agarwal on 18/07/16.
 */
@Immutable
@ParametersAreNonnullByDefault
public class BatchAuditEntityCreationRequest {
    private final List<AuditEntity> auditEntities;

    public BatchAuditEntityCreationRequest(List<AuditEntity> auditEntities) {
        this.auditEntities = ImmutableList.copyOf(auditEntities);
    }

    public List<AuditEntity> getAuditEntities() {
        return auditEntities;
    }

    @Override
    public String toString() {
        return "BatchAuditEntityCreationRequest{"
                + "auditEntities=" + auditEntities
                + '}';
    }
}
