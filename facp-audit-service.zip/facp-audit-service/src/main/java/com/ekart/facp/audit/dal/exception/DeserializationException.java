package com.ekart.facp.audit.dal.exception;

import com.ekart.facp.audit.common.exceptions.ValidationException;

import static com.ekart.facp.audit.common.enums.ErrorCode.DESERIALIZATION_FAILED;

/**
 * Created by akshit.agarwal on 28/05/16.
 */
public class DeserializationException extends ValidationException {
    private static final long serialVersionUID = 1865038236828183907L;

    public DeserializationException(String key, Throwable cause) {
        super("Unable to Deserialize Byte Value for (Key: " + key + ")", DESERIALIZATION_FAILED.name(), cause);
    }
}
