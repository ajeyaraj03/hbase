package com.ekart.facp.audit.apis.dtos.audit;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by akshit.agarwal on 25/07/16.
 */
public class FailedAuditResponse {
    @JsonProperty("entity_name")
    private String entityName;

    @JsonProperty("entity_id")
    private String entityId;

    @JsonProperty("entity_version")
    private long entityVersion;

    @JsonProperty("updated_at_epoch")
    private long updatedAtEpoch;

    @JsonProperty("message")
    private String message;

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public long getEntityVersion() {
        return entityVersion;
    }

    public void setEntityVersion(long entityVersion) {
        this.entityVersion = entityVersion;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    public void setUpdatedAtEpoch(long updatedAtEpoch) {
        this.updatedAtEpoch = updatedAtEpoch;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "AuditResponse{"
                + "entityName='" + entityName + '\''
                + ", entityId='" + entityId + '\''
                + ", entityVersion=" + entityVersion
                + ", updatedAtEpoch=" + updatedAtEpoch
                + ", message='" + message + '\''
                + '}';
    }
}
