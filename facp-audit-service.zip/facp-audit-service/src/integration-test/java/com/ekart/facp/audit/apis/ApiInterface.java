package com.ekart.facp.audit.apis;

import com.ekart.facp.audit.apis.dtos.audit.BatchAuditEntityCreationRequest;
import com.ekart.facp.audit.apis.util.ApiUtil;
import com.google.common.collect.ImmutableMap;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.ws.rs.core.MediaType;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by akshit.agarwal on 31/05/16.
 */
public class ApiInterface {

    private RestTemplate client;
    private String host;
    private String clientName;
    private String tenantName;

    public String getTenantName() {
        return tenantName;
    }

    public void setTenantName(String tenantName) {
        this.tenantName = tenantName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientName() {
        return clientName;
    }

    public ApiInterface() {
    }

    public RestTemplate getClient() {
        return client;
    }

    public void setClient(RestTemplate client) {
        this.client = client;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {

        this.host = host;
    }

    public <T> ResponseEntity<T> createBulkEntityAudit(BatchAuditEntityCreationRequest request,
                                                       Class<T> responseClass) {
        HttpEntity<?> httpRequest = new HttpEntity<>(request, apiHeaders());
        return client.exchange(url("/api/v1/audit/entities"), HttpMethod.PUT, httpRequest, responseClass);
    }

    public <T> ResponseEntity<T> getEntityAudit(String entityName, String entityId, Map<String, Object> queryParam,
                                                Class<T> responseClass) {
        HttpEntity<?> httpRequest = new HttpEntity<>(apiHeaders());
        return client.exchange(url("/api/v1/audit/entities/{entityName}/{entityId}", queryParam), HttpMethod.GET,
                httpRequest, responseClass, entityName, entityId);
    }

    private static HttpHeaders newHeader() {
        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        return header;
    }

    private static HttpHeaders newHeader(Map<String, String> headerContent) {
        HttpHeaders header = newHeader();
        headerContent.forEach((k, v) -> header.add(k, v));
        return header;
    }

    private String url(String urlPath) {
        return url(urlPath, ImmutableMap.of());
    }

    private String url(String urlPath, Map<String, Object> requestParams) {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        requestParams.forEach((k, v) -> params.add(k, v.toString()));

        return UriComponentsBuilder.newInstance().scheme("http").host(host).path(urlPath).queryParams(params)
                .build().toUriString();
    }

    private HttpHeaders apiHeaders() {
        Map<String, String> map = new HashMap<>();
        if (StringUtils.hasText(clientName)) {
            map.put(ApiUtil.CLIENT_KEY, clientName);
        }
        if (StringUtils.hasText(tenantName)) {
            map.put(ApiUtil.TENANT_KEY, tenantName);
        }

        return newHeader(map);
    }

}
