package com.ekart.facp.audit.apis;

import com.ekart.facp.audit.apis.dtos.audit.AuditEntity;
import com.ekart.facp.audit.apis.dtos.audit.EntityAuditSearchResponse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ekart.facp.audit.apis.util.ApiUtil.FROM_TIMESTAMP;
import static com.ekart.facp.audit.apis.util.ApiUtil.TO_TIMESTAMP;

/**
 * Created by akshit.agarwal on 01/06/16.
 */
public final class AuditTestUtil {

    private AuditTestUtil() {
    }

    public static EntityAuditSearchResponse createEntitySearchResponse(List<AuditEntity> auditEntries) {
        EntityAuditSearchResponse entityAuditSearchResponse = new EntityAuditSearchResponse();
        entityAuditSearchResponse.setAuditEntries(auditEntries);
        return entityAuditSearchResponse;
    }

    public static Map<String, Object> searchQueryParams(long fromTimestamp, long toTimestamp) {
        Map<String, Object> params = new HashMap<>(2);
        params.put(FROM_TIMESTAMP, fromTimestamp);
        params.put(TO_TIMESTAMP, toTimestamp);
        return params;
    }
}
