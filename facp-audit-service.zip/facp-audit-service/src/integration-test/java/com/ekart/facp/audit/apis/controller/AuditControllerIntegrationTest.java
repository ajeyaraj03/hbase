package com.ekart.facp.audit.apis.controller;

import com.ekart.facp.audit.apis.BaseIntegrationTest;
import com.ekart.facp.audit.apis.dtos.ErrorMessage;
import com.ekart.facp.audit.apis.dtos.audit.AuditEntity;
import com.ekart.facp.audit.apis.dtos.audit.BatchAuditEntityCreationRequest;
import com.ekart.facp.audit.apis.dtos.audit.EntityAuditSearchResponse;
import com.ekart.facp.audit.apis.dtos.audit.SuccessResponse;
import com.ekart.facp.audit.apis.util.ApiUtil;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections.ListUtils;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.ekart.facp.audit.apis.AuditTestUtil.createEntitySearchResponse;
import static com.ekart.facp.audit.apis.AuditTestUtil.searchQueryParams;
import static com.ekart.facp.audit.common.enums.ErrorCode.VALIDATION_ERROR;
import static com.ekart.facp.audit.common.util.Constraints.AUDIT_ENTITY_LIST_MAX_SIZE;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang.RandomStringUtils.randomAlphanumeric;

/**
 * Created by akshit.agarwal on 30/05/16.
 */
public class AuditControllerIntegrationTest extends BaseIntegrationTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditControllerIntegrationTest.class);

    private static final String ENTITY_NAME = "integration_test";
    private static final String ENTITY_TYPE = "it";
    private static final String CREATED_BY_ACTOR = "created_by";
    private static final String UPDATED_BY_ACTOR = "updated_by";
    private static final long CREATED_AT_EPOCH = 1;
    private static final String UPDATED_BY_PROCESS_ID = "test_process";
    private static final String FACILITY_ID = "mock_facility_id";
    private static final Random RANDOM = new Random();

    private String entityId;
    private long updatedAtEpoch;
    private long entityVersion;
    private Map<String, Object> attributes;

    @BeforeClass
    public static void setUpBefore() {
        API.setTenantName("IT");
        API.setClientName("IntegrationTest");
    }

    @Before
    public void setUp() {
        entityId = randomAlphanumeric(10);
        updatedAtEpoch = System.currentTimeMillis();
        entityVersion = RANDOM.nextInt(10) + 1;
        attributes = Maps.newHashMap();

        // Adding various types for primitive and complex datatypes
        attributes.put(randomAlphabetic(4), RANDOM.nextInt(5));
        attributes.put(randomAlphabetic(5), randomAlphabetic(10));
        attributes.put(randomAlphabetic(6), RANDOM.nextDouble());
        attributes.put(randomAlphabetic(3), RANDOM.nextBoolean());
        attributes.put(randomAlphabetic(3), null);
        attributes.put(randomAlphabetic(3), Lists.newArrayList("a", "b"));
        attributes.put(randomAlphabetic(3), ImmutableMap.of("a", "b"));
    }

    // Bulk insert Test cases
    @Test
    public void shouldReturn400IfEmptyRequestPayloadInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest request = createBatchRequest(0);
        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(request, ErrorMessage.class);

        assertBadRequest(actualResponse, "Audit Entries can not be null or empty", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestIfEmptyEntityDataInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setDataAttributes(ImmutableMap.of());

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "NotEmpty.batchAuditEntityCreationRequest.auditEntities[1].dataAttributes: "
                + "Attributes field cannot be null or empty.", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestIfCreatedAtEpochFieldLessThanZerInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setCreatedAtEpoch(-100L);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "Min.batchAuditEntityCreationRequest.auditEntities[1].createdAtEpoch: "
                + "CreatedAtEpoch field is mandatory and should be > 0", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestIfUpdatedAtEpochFieldLessThanZeroInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setUpdatedAtEpoch(-100L);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "Min.batchAuditEntityCreationRequest.auditEntities[1].updatedAtEpoch: "
                + "UpdatedAtEpoch field is mandatory and should be > 0", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestIfEntityVersionFieldLessThanZeroInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setEntityVersion(-100L);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "Min.batchAuditEntityCreationRequest.auditEntities[1].entityVersion: "
                + "EntityVersion is mandatory and should be > 0", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestWhenEntityNameIsMissingInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setEntityName(null);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "NotNull.batchAuditEntityCreationRequest.auditEntities[1].entityName: "
                + "EntityName field cannot be null or empty.", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestWhenEntityIdIsMissingInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setEntityId(null);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "NotNull.batchAuditEntityCreationRequest.auditEntities[1].entityId: "
                + "EntityId field cannot be null or empty.", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestWhenEntityTypeIsMissingInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setEntityType(null);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "NotNull.batchAuditEntityCreationRequest.auditEntities[1].entityType: "
                + "EntityType field cannot be null or empty.", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestWhenCreatedByActorIsMissingInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setCreatedByActor(null);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "NotNull.batchAuditEntityCreationRequest.auditEntities[1].createdByActor: "
                + "CreatedByActor field cannot be null or empty.", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestWhenUpdatedByActorIsMissingInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setUpdatedByActor(null);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "NotNull.batchAuditEntityCreationRequest.auditEntities[1].updatedByActor: "
                + "UpdatedByActor field cannot be null or empty.", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestWhenFacilityIdIsMissingInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setFacilityId(null);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "NotNull.batchAuditEntityCreationRequest.auditEntities[1].facilityId: "
                + "FacilityId field cannot be null or empty.", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400AndFailRequestWhenUpdatedByProcessIdIsMissingInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(1).setUpdatedByProcessId(null);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "NotNull.batchAuditEntityCreationRequest.auditEntities[1].updatedByProcessId: "
                + "UpdatedByProcessId field cannot be null or empty.", VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400WhenAuditEntriesExceedsMaxLimitInAnyAuditEntryWhileBulkInsertion() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(AUDIT_ENTITY_LIST_MAX_SIZE + 1);

        ResponseEntity<ErrorMessage> actualResponse = API.createBulkEntityAudit(batchRequest, ErrorMessage.class);

        assertBadRequest(actualResponse, "size must be between 1 and " + AUDIT_ENTITY_LIST_MAX_SIZE,
                VALIDATION_ERROR.name());
    }

    @Test
    public void shouldSuccessfullyInsertMultipleAuditEntitiesInBulkInsert() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        bulkCreate(batchRequest);

        EntityAuditSearchResponse expectedSearchResponse = createEntitySearchResponse(batchRequest.getAuditEntities());
        ResponseEntity<EntityAuditSearchResponse> readResponse = readEntityRecord(updatedAtEpoch, updatedAtEpoch + 2);

        assertOk(readResponse, expectedSearchResponse);
    }


    @Test
    public void shouldSuccessfullyInsertMultipleDuplicateAuditEntriesInSameRequestByAppendingUUID() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().set(1, batchRequest.getAuditEntities().get(0));

        bulkCreate(batchRequest);

        EntityAuditSearchResponse expectedSearchResponse = createEntitySearchResponse(batchRequest.getAuditEntities());
        ResponseEntity<EntityAuditSearchResponse> readResponse = readEntityRecord(updatedAtEpoch, updatedAtEpoch + 2);

        assertOk(readResponse, expectedSearchResponse);
    }

    @Test
    public void shouldSuccessfullyInsertDuplicateAuditEntriesComingInDifferentRequestsByAppendingUUID() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(2);

        // Duplicate Bulk create request calls to Audit
        bulkCreate(batchRequest);
        bulkCreate(batchRequest);

        EntityAuditSearchResponse expectedSearchResponse = createEntitySearchResponse(
                Lists.newArrayList(
                        batchRequest.getAuditEntities().get(0),
                        batchRequest.getAuditEntities().get(0),
                        batchRequest.getAuditEntities().get(1),
                        batchRequest.getAuditEntities().get(1)
                )
        );
        ResponseEntity<EntityAuditSearchResponse> readResponse = readEntityRecord(updatedAtEpoch, updatedAtEpoch + 1);

        assertOk(readResponse, expectedSearchResponse);
    }

    /*Test case for maximum batch size bulk insertion*/
    @Test
    public void shouldSuccessfullyInsertMultipleAuditEntitiesInBulkInsertForMaxBatchSize() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(AUDIT_ENTITY_LIST_MAX_SIZE);
        bulkCreate(batchRequest);

        EntityAuditSearchResponse expectedSearchResponse = createEntitySearchResponse(batchRequest.getAuditEntities());
        ResponseEntity<EntityAuditSearchResponse> readResponse = readEntityRecord(updatedAtEpoch,
                updatedAtEpoch + AUDIT_ENTITY_LIST_MAX_SIZE);

        assertOk(readResponse, expectedSearchResponse);
    }

    /**
     * Cannot test partial fail scenerios in case of bulk creates as we dont have a way to fail 1/more records
     * which would required either serialization error or Hbase inaccessible.
     */

    // Search Test Cases
    @Test
    public void shouldReturn400IfNullFromTimestampWhileAuditSearch() {

        Map<String, Object> queryParams = searchQueryParams(updatedAtEpoch, updatedAtEpoch + 1);
        queryParams.remove(ApiUtil.FROM_TIMESTAMP);
        ResponseEntity<ErrorMessage> actualResponse = API.getEntityAudit(ENTITY_NAME, entityId, queryParams,
                ErrorMessage.class);

        assertBadRequest(actualResponse, "Required long parameter 'fromTimestamp' is not present",
                VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400IfNullToTimestampWhileAuditSearch() {

        Map<String, Object> queryParams = searchQueryParams(updatedAtEpoch, updatedAtEpoch + 1);
        queryParams.remove(ApiUtil.TO_TIMESTAMP);
        ResponseEntity<ErrorMessage> actualResponse = API.getEntityAudit(ENTITY_NAME, entityId,
                queryParams, ErrorMessage.class);

        assertBadRequest(actualResponse, "Required long parameter 'toTimestamp' is not present",
                VALIDATION_ERROR.name());
    }

    @Test
    public void shouldReturn400IfToTimestampLessThanFromTimestampWhileAuditSearch() {

        Map<String, Object> queryParams = searchQueryParams(updatedAtEpoch + 1, updatedAtEpoch);
        ResponseEntity<ErrorMessage> actualResponse = API.getEntityAudit(ENTITY_NAME, entityId, queryParams,
                ErrorMessage.class);

        assertBadRequest(actualResponse, "EndTimestamp " + updatedAtEpoch + " should be >= than startTimestamp "
                + (updatedAtEpoch + 1), VALIDATION_ERROR.name());
    }

    @Test
    public void shouldFetchRecordsForOnlyQueriedPeriodOfTimeAndSortedByTime() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        bulkCreate(batchRequest);

        EntityAuditSearchResponse expectedSearchResponse =
                createEntitySearchResponse(batchRequest.getAuditEntities().subList(0, 2));
        ResponseEntity<EntityAuditSearchResponse> readResponse = readEntityRecord(updatedAtEpoch, updatedAtEpoch + 1);

        assertOk(readResponse, expectedSearchResponse);
    }

    @Test
    public void shouldFetchOutOfOrderByTimeInsertedRecordsInDifferentRequestsForGivenPeriodSortedByTime() {

        BatchAuditEntityCreationRequest batchRequest1 = createBatchRequest(2);
        batchRequest1.getAuditEntities().get(0).setUpdatedAtEpoch(updatedAtEpoch + 4);
        batchRequest1.getAuditEntities().get(1).setUpdatedAtEpoch(updatedAtEpoch + 5);
        bulkCreate(batchRequest1);

        BatchAuditEntityCreationRequest batchRequest2 = createBatchRequest(2);
        batchRequest2.getAuditEntities().get(0).setUpdatedAtEpoch(updatedAtEpoch + 2);
        batchRequest2.getAuditEntities().get(1).setUpdatedAtEpoch(updatedAtEpoch + 3);
        bulkCreate(batchRequest2);

        EntityAuditSearchResponse expectedSearchResponse = createEntitySearchResponse(
                ListUtils.union(batchRequest2.getAuditEntities(), batchRequest1.getAuditEntities()));

        ResponseEntity<EntityAuditSearchResponse> readResponse = readEntityRecord(updatedAtEpoch + 2,
                updatedAtEpoch + 5);

        assertOk(readResponse, expectedSearchResponse);
    }

    @Test
    public void shouldFetchOutOfOrderByTimeInsertedRecordsInSameRequestForGivenPeriodSortedByTime() {

        BatchAuditEntityCreationRequest batchRequest = createBatchRequest(3);
        batchRequest.getAuditEntities().get(0).setUpdatedAtEpoch(updatedAtEpoch + 4);
        batchRequest.getAuditEntities().get(1).setUpdatedAtEpoch(updatedAtEpoch + 2);
        batchRequest.getAuditEntities().get(2).setUpdatedAtEpoch(updatedAtEpoch);

        bulkCreate(batchRequest);

        EntityAuditSearchResponse expectedSearchResponse = createEntitySearchResponse(
                Lists.newArrayList(
                        batchRequest.getAuditEntities().get(2),
                        batchRequest.getAuditEntities().get(1),
                        batchRequest.getAuditEntities().get(0))
        );

        ResponseEntity<EntityAuditSearchResponse> readResponse = readEntityRecord(updatedAtEpoch,
                updatedAtEpoch + 4);

        assertOk(readResponse, expectedSearchResponse);
    }

    @Test
    public void shouldFetchEmptyRecordsWhenNoAuditRecordPresentInGivenTimestamps() {

        EntityAuditSearchResponse expectedSearchResponse = createEntitySearchResponse(Lists.newArrayList());

        ResponseEntity<EntityAuditSearchResponse> readResponse = readEntityRecord(updatedAtEpoch, updatedAtEpoch + 10);

        assertOk(readResponse, expectedSearchResponse);
    }

    private BatchAuditEntityCreationRequest createBatchRequest(int noOfRecords) {

        List<AuditEntity> entities = IntStream.range(0, noOfRecords).mapToObj(i ->
                createAuditEntry(ENTITY_NAME, entityId, entityVersion, CREATED_AT_EPOCH, updatedAtEpoch + i,
                        attributes))
                .collect(Collectors.toList());

        BatchAuditEntityCreationRequest batchCreationRequest = new BatchAuditEntityCreationRequest();
        batchCreationRequest.setAuditEntities(entities);
        return batchCreationRequest;
    }

    private ResponseEntity<SuccessResponse> bulkCreate(BatchAuditEntityCreationRequest batchRequest) {

        ResponseEntity<SuccessResponse> actualResponse = API.createBulkEntityAudit(batchRequest, SuccessResponse.class);
        assertCreated(actualResponse);
        return actualResponse;
    }

    private ResponseEntity<EntityAuditSearchResponse> readEntityRecord(long startTimestamp, long endTimestamp) {

        LOGGER.info("Reading table data for entityName: {}, entityId: {}", ENTITY_NAME, entityId);
        ResponseEntity<EntityAuditSearchResponse> actualResponse = API.getEntityAudit(ENTITY_NAME, entityId,
                searchQueryParams(startTimestamp, endTimestamp), EntityAuditSearchResponse.class);

        assertOk(actualResponse);

        return actualResponse;
    }

    private AuditEntity createAuditEntry(String entityName, String entityId, long version, long createdAt,
                                        long updatedAt, Map<String, Object> attributes) {

        AuditEntity auditEntity = new AuditEntity();
        auditEntity.setEntityName(entityName);
        auditEntity.setEntityId(entityId);
        auditEntity.setDataAttributes(attributes);
        auditEntity.setEntityVersion(version);
        auditEntity.setCreatedAtEpoch(createdAt);
        auditEntity.setUpdatedAtEpoch(updatedAt);
        auditEntity.setEntityType(ENTITY_TYPE);
        auditEntity.setCreatedByActor(CREATED_BY_ACTOR);
        auditEntity.setUpdatedByActor(UPDATED_BY_ACTOR);
        auditEntity.setFacilityId(FACILITY_ID);
        auditEntity.setUpdatedByProcessId(UPDATED_BY_PROCESS_ID);
        return auditEntity;
    }
}
