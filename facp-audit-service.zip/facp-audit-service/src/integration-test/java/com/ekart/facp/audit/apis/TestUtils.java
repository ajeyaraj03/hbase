package com.ekart.facp.audit.apis;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * @author vijay.daniel
 *
 */
public final class TestUtils {

   private TestUtils() {
   }

   public static <T> void assertResponse(ResponseEntity<T> actualResponse, HttpStatus expectedStatus, T expectedBody) {

      assertThat(actualResponse.getStatusCode(), is(expectedStatus));
      assertReflectionEquals(expectedBody, actualResponse.getBody());
   }
}
