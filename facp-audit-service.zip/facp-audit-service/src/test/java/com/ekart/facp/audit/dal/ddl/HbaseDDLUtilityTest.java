package com.ekart.facp.audit.dal.ddl;

import com.ekart.facp.audit.apis.dtos.audit.HbaseTableConfig;
import com.ekart.facp.audit.dal.exception.InvalidDDLSpecificationException;
import com.ekart.facp.audit.common.util.TenantContext;
import com.google.common.collect.Lists;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableExistsException;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by akshit.agarwal on 01/06/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class HbaseDDLUtilityTest {

    private static final String TABLE_NAME = "ut";
    private static final String COLUMN_FAMILY = "cf";

    @Mock
    private HBaseAdmin admin;
    @Mock
    private HbaseTableConfig tableConfig;

    private HbaseDDLUtility hbaseDDLUtility;
    private TenantContext tenantContext;

    @Before
    public void setUp() {
        hbaseDDLUtility = new HbaseDDLUtility(admin, tableConfig);
        tenantContext = new TenantContext();
        tableConfig = new HbaseTableConfig(1);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowWhenNullInstanceOfAdmin() {
        new HbaseDDLUtility(null, tableConfig);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowWhenNullInstanceOfTableConfig() {
        new HbaseDDLUtility(admin, null);
    }

    @Test(expected = InvalidDDLSpecificationException.class)
    public void shouldThrowErrorWhenTableAlreadyExist() throws IOException {
        doThrow(new TableExistsException()).when(admin).createTable(any(HTableDescriptor.class));
        hbaseDDLUtility.create(tenantContext, TABLE_NAME, Lists.newArrayList(COLUMN_FAMILY));
    }

    @Test(expected = InvalidDDLSpecificationException.class)
    public void shouldThrowErrorWhenIOException() throws IOException {
        when(admin.tableExists(any(TableName.class))).thenReturn(false);
        doThrow(new IOException()).when(admin).createTable(any(HTableDescriptor.class));
        hbaseDDLUtility.create(tenantContext, TABLE_NAME, Lists.newArrayList(COLUMN_FAMILY));
    }

    @Test
    public void shouldCreateTable() throws IOException {
        when(admin.tableExists(any(TableName.class))).thenReturn(false);
        doNothing().when(admin).createTable(any(HTableDescriptor.class));
        hbaseDDLUtility.create(tenantContext, TABLE_NAME, Lists.newArrayList(COLUMN_FAMILY));
        verify(admin).createTable(any(HTableDescriptor.class));
    }
}
