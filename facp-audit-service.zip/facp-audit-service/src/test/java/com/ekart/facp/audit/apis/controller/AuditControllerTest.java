package com.ekart.facp.audit.apis.controller;

import com.ekart.facp.audit.apis.dtos.audit.BatchAuditEntityCreationRequest;
import com.ekart.facp.audit.apis.dtos.audit.EntityAuditSearchResponse;
import com.ekart.facp.audit.apis.dtos.audit.FailedAuditResponse;
import com.ekart.facp.audit.apis.dtos.audit.SuccessResponse;
import com.ekart.facp.audit.apis.exception.BatchProcessingException;
import com.ekart.facp.audit.apis.exception.InvalidInputException;
import com.ekart.facp.audit.apis.mapper.ApiServiceDtoMapper;
import com.ekart.facp.audit.common.util.TenantContext;
import com.ekart.facp.audit.service.AuditService;
import com.ekart.facp.audit.service.dtos.AuditResponse;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.*;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by akshit.agarwal on 30/05/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class AuditControllerTest {

    private static final String ENTITY_ID = "100";
    private static final String ENTITY_NAME = "audit";
    private static final long UPDATED_AT_EPOCH = 145244568;
    private static final String CLIENT = "mockClient";
    private static final String TENANT = "mockTenant";

    @Mock
    private AuditService auditService;

    @Mock
    private ApiServiceDtoMapper mapper;

    @Mock
    private BatchAuditEntityCreationRequest apiRequest;

    @Mock
    private com.ekart.facp.audit.service.dtos.BatchAuditEntityCreationRequest serviceRequest;

    @Mock
    private FailedAuditResponse failedAuditResponse;

    @Mock
    private com.ekart.facp.audit.service.dtos.AuditEntity serviceAuditEntity;

    private TenantContext tenantContext;

    private AuditController auditController;

    @Before
    public void setUp() {

        auditController = new AuditController(auditService, mapper);
        tenantContext = new TenantContext();
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowErrorWhenServiceInstanceIsNull() {
        new AuditController(null, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowErrorWhenMapperInstanceIsNull() {
        new AuditController(auditService, null);
    }

    @Test
    public void shouldCreateBulkAuditEntitiesAndReturnSuccessWhenAllSuccessfull() {

        List<AuditResponse> bulkCreateResponse = Lists.newArrayList(auditResponse(true), auditResponse(true));

        when(mapper.apiToServiceBatchAuditEntityCreationRequest(apiRequest)).thenReturn(serviceRequest);
        when(auditService.bulkCreate(tenantContext, serviceRequest)).thenReturn(bulkCreateResponse);

        ResponseEntity<SuccessResponse> actualResponse = auditController.bulkCreate(apiRequest, CLIENT, TENANT);

        assertThat(actualResponse.getStatusCode(), is(HttpStatus.CREATED));
        assertReflectionEquals(actualResponse.getBody(), new SuccessResponse());
    }

    @Test(expected = BatchProcessingException.class)
    public void shouldThrowBatchProcessingErrorWhenCreationFailsForAnyAuditEntry() {

        List<AuditResponse> bulkCreateResponse = Lists.newArrayList(auditResponse(false), auditResponse(false),
                auditResponse(true));
        List<FailedAuditResponse> failedAuditResponses = Lists.newArrayList(failedAuditResponse);

        when(mapper.apiToServiceBatchAuditEntityCreationRequest(apiRequest)).thenReturn(serviceRequest);
        when(auditService.bulkCreate(tenantContext, serviceRequest)).thenReturn(bulkCreateResponse);
        when(mapper.serviceToApiFailedAuditResponses(bulkCreateResponse.subList(0, 2)))
                .thenReturn(failedAuditResponses);

        auditController.bulkCreate(apiRequest, CLIENT, TENANT);
        verify(auditService).bulkCreate(tenantContext, serviceRequest);
    }

    @Test(expected = InvalidInputException.class)
    public void shouldThrowErrorWhenInvalidFromTimestamp() {

        auditController.getEntityAudit(ENTITY_NAME, ENTITY_ID, -1, UPDATED_AT_EPOCH + 1, CLIENT, TENANT);
    }

    @Test(expected = InvalidInputException.class)
    public void shouldThrowErrorWhenInvalidToTimestamp() {

        auditController.getEntityAudit(ENTITY_NAME, ENTITY_ID, UPDATED_AT_EPOCH, -1, CLIENT, TENANT);
    }

    @Test(expected = InvalidInputException.class)
    public void shouldThrowErrorWhenFromTimestampLessThanToTimestamp() {

        auditController.getEntityAudit(ENTITY_NAME, ENTITY_ID, UPDATED_AT_EPOCH, UPDATED_AT_EPOCH - 1, CLIENT, TENANT);
    }

    @Test
    public void shouldFetchAuditEntriesAsPerCriteria() {
        List<com.ekart.facp.audit.service.dtos.AuditEntity> auditEntries = Lists.newArrayList(
                getServiceAuditEntity(), getServiceAuditEntity(), getServiceAuditEntity());

        EntityAuditSearchResponse expectedResponse = mock(EntityAuditSearchResponse.class);

        when(auditService.findEntries(tenantContext, ENTITY_NAME, ENTITY_ID, UPDATED_AT_EPOCH,
                UPDATED_AT_EPOCH + 1)).thenReturn(auditEntries);
        when(mapper.serviceToApiEntityAuditSearchResponse(auditEntries)).thenReturn(expectedResponse);

        ResponseEntity<EntityAuditSearchResponse> actualResponse = auditController.
                getEntityAudit(ENTITY_NAME, ENTITY_ID, UPDATED_AT_EPOCH, UPDATED_AT_EPOCH + 1, CLIENT, TENANT);

        assertThat(actualResponse.getStatusCode(), is(HttpStatus.OK));
        assertReflectionEquals(expectedResponse, actualResponse.getBody());
    }

    private AuditResponse auditResponse(boolean success) {
        AuditResponse auditResponse = mock(AuditResponse.class);
        when(auditResponse.isSuccess()).thenReturn(success);
        return auditResponse;
    }

    private com.ekart.facp.audit.service.dtos.AuditEntity getServiceAuditEntity() {
        return mock(com.ekart.facp.audit.service.dtos.AuditEntity.class);
    }
}
