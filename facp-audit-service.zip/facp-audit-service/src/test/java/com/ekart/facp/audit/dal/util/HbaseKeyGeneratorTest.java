package com.ekart.facp.audit.dal.util;

import com.google.common.primitives.Bytes;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

/**
 * Created by akshit.agarwal on 07/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class HbaseKeyGeneratorTest {
    private static final String ENTITY_NAME = "item";
    private static final String ENTITY_ID = "1";
    private static final long TIMESTAMP = 10;
    private static final long VERSION = 3;

    private HbaseKeyGenerator hbaseKeyGenerator;

    @Before
    public void setUp() {
        hbaseKeyGenerator = new HbaseKeyGenerator();
    }

    @Test
    public void shouldEncodeRowKey() {
        // This is actual byteArray value for the given Parameters
        byte[] expectedRowKeyWithoutUUID = new byte[] {-109, -84, 22, -108, 47, 47, 105, 116, 101, 109, 47, 47, 49,
                47, 47, 0, 0, 0, 0, 0, 0, 0, 10, 47, 47, 0, 0, 0, 0, 0, 0, 0, 3, 47, 47};

        byte[] actualRowKey = hbaseKeyGenerator.encodeRowKey(ENTITY_NAME, ENTITY_ID, TIMESTAMP, VERSION);

        // assertion shows expectedRowKey is subset of rowkey starting from index 0 or first byte
        assertThat(Bytes.indexOf(actualRowKey, expectedRowKeyWithoutUUID), is(0));
    }

    @Test
    public void shouldEncodePrefixedRowKey() {
        // This is actual byteArray value for the given Parameters
        byte[] expectedPrefiedRowKey = new byte[] {-109, -84, 22, -108, 47, 47, 105, 116, 101, 109, 47, 47, 49,
                47, 47, 0, 0, 0, 0, 0, 0, 0, 10, 47, 47};

        byte[] actualPrefixedRowKey = hbaseKeyGenerator.generatePrefixedRowKey(ENTITY_NAME, ENTITY_ID, TIMESTAMP);

        assertThat(actualPrefixedRowKey, is(expectedPrefiedRowKey));
    }

    @Test
    public void shouldConvertStringToBytes() {
        // This is actual byteArray value for the given Parameters
        byte[] expectedBytes = new byte[] {105, 116, 101, 109};

        byte[] actualBytes = hbaseKeyGenerator.convertStringToBytes(ENTITY_NAME);

        assertThat(actualBytes, is(expectedBytes));
    }
}
