package com.ekart.facp.audit.dal;

import com.ekart.facp.audit.common.util.TenantContext;
import com.ekart.facp.audit.dal.dtos.AuditEntity;
import com.ekart.facp.audit.dal.exception.InvalidDataAccessException;
import com.ekart.facp.audit.dal.exception.SerializationException;
import com.ekart.facp.audit.dal.util.Constants;
import com.ekart.facp.audit.dal.util.HbaseKeyGenerator;
import com.ekart.facp.audit.dal.util.HbaseUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import jersey.repackaged.com.google.common.collect.ImmutableMap;
import org.apache.hadoop.hbase.client.Scan;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.hadoop.hbase.HbaseSystemException;
import org.springframework.data.hadoop.hbase.HbaseTemplate;
import org.springframework.data.hadoop.hbase.ResultsExtractor;
import org.springframework.data.hadoop.hbase.TableCallback;

import java.util.List;
import java.util.Map;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by akshit.agarwal on 31/05/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class HbaseRepositoryImplTest {

    private static final String ENTITY_NAME = "item";
    private static final String ENTITY_ID = "1";
    private static final String ENTITY_TYPE = "bag";
    private static final long VERSION = 1;
    private static final String CREATED_BY_ACTOR = "mockito_junit";
    private static final long UPDATED_AT_EPOCH = 145244567;
    private static final String UPDATED_BY_PROCESS_ID = "test_process";
    private static final String FACILITY_ID = "localhost";
    private static final Map<String, Object> DATA_ATTRIBUTES = ImmutableMap.of("key", "value");
    private static final Map<String, Object> ATTRIBUTES = ImmutableMap.of("entityId", ENTITY_ID, "data.key", "value");
    private static final byte[] MOCK_BYTE = new byte[]{(byte) 0x01 };
    private static final String TABLE_NAME = Constants.DEFAULT_HBASE_TABLE_NAME;
    private static final String COLUMN_FAMILY = Constants.DEFAULT_COLUMN_FAMILY_NAME;

    @Mock
    private HbaseTemplate hbaseTemplate;
    @Mock
    private ObjectMapper mapper;
    @Mock
    private HbaseKeyGenerator hbaseKeyGenerator;
    @Mock
    private HbaseUtility hbaseUtility;

    private HbaseRepositoryImpl hbaseRepository;
    private TenantContext tenantContext;
    private List<AuditEntity> auditEntities;

    @Before
    public void setUp() {

        hbaseRepository = new HbaseRepositoryImpl(hbaseTemplate, mapper, hbaseKeyGenerator, hbaseUtility);
        tenantContext = new TenantContext();
        auditEntities = getAuditEntities(5);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowWhenHbaseTemplateInstanceIsNull() {

        new HbaseRepositoryImpl(null, mapper, hbaseKeyGenerator, hbaseUtility);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowWhenMapperInstanceIsNull() {

        new HbaseRepositoryImpl(hbaseTemplate, null, hbaseKeyGenerator, hbaseUtility);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowWhenKeyGeneratorInstanceIsNull() {

        new HbaseRepositoryImpl(hbaseTemplate, mapper, null, hbaseUtility);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowWhenHbaseUtilityInstanceIsNull() {

        new HbaseRepositoryImpl(hbaseTemplate, mapper, hbaseKeyGenerator, null);
    }

    @Test(expected = SerializationException.class)
    public void shouldThrowWhenInvalidSerializableObject() throws JsonProcessingException {

        // We need to mock as we cannot instantiate this exception, protected constructors
        JsonProcessingException mockException = mock(JsonProcessingException.class);

        mockKeyGeneratorCallsForSave();
        when(mapper.writeValueAsBytes(ENTITY_ID)).thenThrow(mockException);

        hbaseRepository.save(tenantContext, auditEntities);
    }

    @Test(expected = InvalidDataAccessException.class)
    public void shouldThrowWhenPutInHbaseFails() {

        // We need to mock this, as initialization of this takes valid cause, which we dont want to mock/create
        HbaseSystemException mockException = mock(HbaseSystemException.class);

        mockKeyGeneratorCallsForSave();
        mockSerializationCallsForSave();
        when(hbaseTemplate.execute(eq(TABLE_NAME), Mockito.<TableCallback>anyObject())).thenThrow(mockException);

        hbaseRepository.save(tenantContext, getAuditEntities(1));
    }

    @Test
    public void shouldSuccessfullySaveEntityAttributesToHbase() {
        mockKeyGeneratorCallsForSave();
        mockSerializationCallsForSave();
        when(hbaseTemplate.execute(eq(TABLE_NAME), Mockito.<TableCallback>anyObject())).thenReturn(null);

        hbaseRepository.save(tenantContext, getAuditEntities(1));
    }

    @Test(expected = InvalidDataAccessException.class)
    public void shouldThrowWhenFailsToReadFromHbase() throws JsonProcessingException {

        // We need to mock this, as initialization of this takes valid cause, which we dont want to mock/create
        HbaseSystemException mockException = mock(HbaseSystemException.class);
        long fromTs = UPDATED_AT_EPOCH;
        long toTs = UPDATED_AT_EPOCH + 1;

        mockKeyGeneratorCallsForRead(fromTs, toTs);
        when(hbaseTemplate.find(eq(TABLE_NAME), any(Scan.class), any(ResultsExtractor.class))).thenThrow(mockException);

        hbaseRepository.findbyIdAndTimeRange(tenantContext, ENTITY_NAME, ENTITY_ID, fromTs, toTs);
    }

    @Test
    public void shouldSuccessfullyFetchRecordsFromHbase() throws JsonProcessingException {

        long fromTs = UPDATED_AT_EPOCH;
        long toTs = UPDATED_AT_EPOCH + 1;

        mockKeyGeneratorCallsForRead(fromTs, toTs);
        when(hbaseTemplate.find(eq(TABLE_NAME), any(Scan.class), any(ResultsExtractor.class)))
                .thenReturn(auditEntities);

        List<AuditEntity> actualResult =
                hbaseRepository.findbyIdAndTimeRange(tenantContext, ENTITY_NAME, ENTITY_ID, fromTs, toTs);

        assertReflectionEquals(auditEntities, actualResult);
    }

    private void mockKeyGeneratorCallsForSave() {

        when(hbaseKeyGenerator.encodeRowKey(ENTITY_NAME, ENTITY_ID, UPDATED_AT_EPOCH, VERSION)).thenReturn(MOCK_BYTE);
        when(hbaseKeyGenerator.convertStringToBytes(COLUMN_FAMILY)).thenReturn(MOCK_BYTE);
        when(hbaseUtility.convertAuditEntityToMap(auditEntities.get(0))).thenReturn(ATTRIBUTES);
    }

    private void mockSerializationCallsForSave() {

        ATTRIBUTES.forEach((k, v) -> {
            try {
                when(mapper.writeValueAsBytes(k)).thenReturn(MOCK_BYTE);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e.getMessage(), e);
            }
            when(hbaseKeyGenerator.convertStringToBytes(k)).thenReturn(MOCK_BYTE);
        });
    }

    private void mockKeyGeneratorCallsForRead(long fromTs, long toTs) {

        when(hbaseKeyGenerator.generatePrefixedRowKey(ENTITY_NAME, ENTITY_ID, fromTs)).thenReturn(MOCK_BYTE);
        when(hbaseKeyGenerator.generatePrefixedRowKey(ENTITY_NAME, ENTITY_ID, toTs + 1)).thenReturn(MOCK_BYTE);
        when(hbaseKeyGenerator.convertStringToBytes(COLUMN_FAMILY)).thenReturn(MOCK_BYTE);
    }

    private List<AuditEntity> getAuditEntities(int noOfEntities) {

        List<AuditEntity> entities = Lists.newArrayListWithCapacity(noOfEntities);
        for (int i = 0; i < noOfEntities; i++) {
            entities.add(new AuditEntity(ENTITY_NAME, ENTITY_ID, VERSION + i, ENTITY_TYPE, CREATED_BY_ACTOR,
                    UPDATED_AT_EPOCH, CREATED_BY_ACTOR, UPDATED_AT_EPOCH + i, UPDATED_BY_PROCESS_ID,
                    FACILITY_ID, DATA_ATTRIBUTES));
        }
        return entities;
    }

}
