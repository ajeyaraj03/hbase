package com.ekart.facp.audit.service;

import com.ekart.facp.audit.common.exceptions.ValidationException;
import com.ekart.facp.audit.common.util.TenantContext;
import com.ekart.facp.audit.dal.AuditEntityRepository;
import com.ekart.facp.audit.service.dtos.AuditEntity;
import com.ekart.facp.audit.service.dtos.AuditResponse;
import com.ekart.facp.audit.service.dtos.BatchAuditEntityCreationRequest;
import com.ekart.facp.audit.service.mapper.ServiceRepositoryDtoMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.apache.commons.collections.ListUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static com.ekart.facp.audit.common.util.Constraints.AUDIT_ENTITY_LIST_MAX_SIZE;
import static com.ekart.facp.audit.service.util.Constants.SUCCESS_CREATE_AUDIT_MESSAGE;
import static org.mockito.Mockito.*;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by akshit.agarwal on 30/05/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class AuditServiceImplTest {

    private static final String ENTITY_ID = "100";
    private static final String ENTITY_NAME = "audit";
    private static final long ENTITY_VERSION = 1;
    private static final String ENTITY_TYPE = "ut";
    private static final String CREATED_BY_ACTOR = "mockito_junit";
    private static final long UPDATED_AT_EPOCH = 145244567;
    private static final String UPDATED_BY_PROCESS_ID = "test_process";
    private static final String FACILITY_ID = "localhost";
    private static final Map<String, Object> DATA_ATTRIBUTES = ImmutableMap.of("key", "value");

    @Mock
    private AuditEntityRepository auditEntityRepository;
    @Mock
    private ServiceRepositoryDtoMapper mapper;

    private AuditServiceImpl auditServiceImpl;
    private TenantContext tenantContext;

    @Before
    public void setUp() {
        auditServiceImpl = new AuditServiceImpl(auditEntityRepository, mapper);
        tenantContext = new TenantContext();
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowWhenRespositoryInstanceIsNull() {
        new AuditServiceImpl(null, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowWhenDtoMapperInstanceIsNull() {
        new AuditServiceImpl(auditEntityRepository, null);
    }

    @Test
    public void shouldSuccessfullyCallRepositoryForBulkInsertRequest() {

        BatchAuditEntityCreationRequest request = createBatchAuditEntry(3);

        List<com.ekart.facp.audit.dal.dtos.AuditEntity> repoAuditEntities =
                Lists.newArrayList(repoAuditEntity(), repoAuditEntity(), repoAuditEntity());
            when(mapper.serviceToRepositoryAuditEntities(request.getAuditEntities())).thenReturn(repoAuditEntities);
            doNothing().when(auditEntityRepository).save(tenantContext, repoAuditEntities);

        List<AuditResponse> actualResponse = auditServiceImpl.bulkCreate(tenantContext, request);

            verify(auditEntityRepository).save(tenantContext, repoAuditEntities);
        assertReflectionEquals(getSuccessAuditResponses(request.getAuditEntities()), actualResponse);
    }

    @Test
    public void shouldCatchValidationExceptionThrownByRepository() {

        BatchAuditEntityCreationRequest request = createBatchAuditEntry(3);
        List<com.ekart.facp.audit.dal.dtos.AuditEntity> repoAuditEntities =
                 Lists.newArrayList(repoAuditEntity(), repoAuditEntity(), repoAuditEntity());
        String errorMessage = "Error Here";

        when(mapper.serviceToRepositoryAuditEntities(request.getAuditEntities())).thenReturn(repoAuditEntities);
            doThrow(exception(errorMessage)).when(auditEntityRepository).save(tenantContext, repoAuditEntities);

        List<AuditResponse> actualResponse = auditServiceImpl.bulkCreate(tenantContext, request);

        verify(auditEntityRepository).save(tenantContext, repoAuditEntities);
        assertReflectionEquals(getFailedAuditResponses(request.getAuditEntities(), errorMessage), actualResponse);
    }

    @Test
    public void shouldHandlePartialSuccessWhileBulkCreate() {

        BatchAuditEntityCreationRequest request = createBatchAuditEntry(8000);
        String errorMessage = "Error Here";

        List<List<AuditEntity>> partionedAuditEntities = Lists.partition(request.getAuditEntities(),
                AUDIT_ENTITY_LIST_MAX_SIZE);

        // Success
        List<com.ekart.facp.audit.dal.dtos.AuditEntity> repoAuditEntitiesSuccess = mock(ArrayList.class);
        when(mapper.serviceToRepositoryAuditEntities(partionedAuditEntities.get(0)))
                .thenReturn(repoAuditEntitiesSuccess);

        doNothing().when(auditEntityRepository).save(tenantContext, repoAuditEntitiesSuccess);

        // Failure
        List<com.ekart.facp.audit.dal.dtos.AuditEntity> repoAuditEntitiesFailure = mock(ArrayList.class);
        when(mapper.serviceToRepositoryAuditEntities(partionedAuditEntities.get(1)))
                .thenReturn(repoAuditEntitiesFailure);
        doThrow(exception(errorMessage)).when(auditEntityRepository).save(tenantContext, repoAuditEntitiesFailure);

        List<AuditResponse> actualResponse = auditServiceImpl.bulkCreate(tenantContext, request);

        verify(auditEntityRepository).save(tenantContext, repoAuditEntitiesSuccess);
        verify(auditEntityRepository).save(tenantContext, repoAuditEntitiesFailure);

        List<AuditResponse> expectedResponse = ListUtils.union(
                getSuccessAuditResponses(partionedAuditEntities.get(0)),
                getFailedAuditResponses(partionedAuditEntities.get(1), errorMessage)
        );

        assertReflectionEquals(expectedResponse, actualResponse);
    }


    /*Partitioned batch test */
    @Test
    public void shouldSuccessfullyCallRepositoryForBulkInsertRequestForDataMoreThanChunkSize() {

        BatchAuditEntityCreationRequest request = createBatchAuditEntry(8000);
        List<com.ekart.facp.audit.dal.dtos.AuditEntity> repoAuditEntities = mock(ArrayList.class);

            List<List<AuditEntity>> partionedAuditEntities = Lists.partition(request.getAuditEntities(),
                    AUDIT_ENTITY_LIST_MAX_SIZE);
        partionedAuditEntities.forEach(auditEntities -> {
            when(mapper.serviceToRepositoryAuditEntities(auditEntities)).thenReturn(repoAuditEntities);
            doNothing().when(auditEntityRepository).save(tenantContext, repoAuditEntities);

        });

        List<AuditResponse> actualResponse = auditServiceImpl.bulkCreate(tenantContext, request);

        verify(auditEntityRepository, times(2)).save(tenantContext, repoAuditEntities);
        assertReflectionEquals(getSuccessAuditResponses(request.getAuditEntities()), actualResponse);
    }

    @Test
    public void shouldCallRepositoryForScanOnTimerange() {

        List<AuditEntity> auditEntities = Lists.newArrayList(mock(AuditEntity.class), mock(AuditEntity.class));
        List<com.ekart.facp.audit.dal.dtos.AuditEntity> repositoryAuditEntities =
                Lists.newArrayList(repoAuditEntity(), repoAuditEntity());

        when(auditEntityRepository.findbyIdAndTimeRange(tenantContext, ENTITY_NAME, ENTITY_ID,
                        UPDATED_AT_EPOCH, UPDATED_AT_EPOCH + 1)).thenReturn(repositoryAuditEntities);
        when(mapper.repositoryToServiceAuditEntities(repositoryAuditEntities)).thenReturn(auditEntities);

        List<AuditEntity> actualResult = auditServiceImpl.findEntries(tenantContext, ENTITY_NAME, ENTITY_ID,
                UPDATED_AT_EPOCH, UPDATED_AT_EPOCH + 1);

        assertReflectionEquals(auditEntities, actualResult);
    }

    private BatchAuditEntityCreationRequest createBatchAuditEntry(int noOfEntries) {
        return new BatchAuditEntityCreationRequest((
                IntStream.range(0, noOfEntries)
                        .mapToObj(i -> new AuditEntity(ENTITY_NAME, ENTITY_ID, ENTITY_VERSION, ENTITY_TYPE,
                                CREATED_BY_ACTOR, UPDATED_AT_EPOCH, CREATED_BY_ACTOR, UPDATED_AT_EPOCH,
                                UPDATED_BY_PROCESS_ID, FACILITY_ID, DATA_ATTRIBUTES))
                        .collect(Collectors.toList()))
        );
    }

    private BatchAuditEntityCreationRequest createBatchAuditResponse(int noOfEntries) {
        return new BatchAuditEntityCreationRequest((
                IntStream.range(0, noOfEntries)
                        .mapToObj(i -> new AuditEntity(ENTITY_NAME, ENTITY_ID, ENTITY_VERSION, ENTITY_TYPE,
                                CREATED_BY_ACTOR, UPDATED_AT_EPOCH, CREATED_BY_ACTOR, UPDATED_AT_EPOCH,
                                UPDATED_BY_PROCESS_ID, FACILITY_ID, DATA_ATTRIBUTES))
                        .collect(Collectors.toList()))
        );
    }

    private List<AuditResponse> getSuccessAuditResponses(List<AuditEntity> auditEntities) {
        return auditEntities.stream().map(auditEntity ->
                        new AuditResponse(
                                auditEntity.getEntityName(), auditEntity.getEntityId(),
                                auditEntity.getEntityVersion(), auditEntity.getUpdatedAtEpoch(),
                                true, SUCCESS_CREATE_AUDIT_MESSAGE)
        ).collect(Collectors.toList());
    }

    private List<AuditResponse> getFailedAuditResponses(List<AuditEntity> auditEntities, String errorMessage) {
        return auditEntities.stream().map(auditEntity ->
                        new AuditResponse(
                                auditEntity.getEntityName(), auditEntity.getEntityId(),
                                auditEntity.getEntityVersion(), auditEntity.getUpdatedAtEpoch(),
                                false, errorMessage)
        ).collect(Collectors.toList());
    }

    private com.ekart.facp.audit.dal.dtos.AuditEntity repoAuditEntity() {
        return mock(com.ekart.facp.audit.dal.dtos.AuditEntity.class);
    }

    private ValidationException exception(String message) {
        ValidationException exception = mock(ValidationException.class);
        when(exception.getMessage()).thenReturn(message);
        return exception;
    }
}
