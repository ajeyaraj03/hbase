package com.ekart.facp.audit.dal.util;

import com.ekart.facp.audit.dal.dtos.AuditEntity;
import com.ekart.facp.audit.dal.exception.DeserializationException;
import com.ekart.facp.audit.dal.exception.DuplicateAttributeException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Result;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;

import static com.ekart.facp.audit.dal.util.Constants.DATA_ATTRIBUTES_KEY_NAME;
import static com.ekart.facp.audit.dal.util.Constants.DATA_ATTRIBUTES_PREFIX;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by akshit.agarwal on 29/07/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class HbaseUtilityTest {

    private static final String TABLE_NAME = "t1";
    private static final String COLUMN_FAMILY = "cf";

    private static final Map<String, Object> AUDIT_MANDATORY_ATTRIBUTES = ImmutableMap.of("mandatory-key", "value1");
    private static final Map<String, Object> AUDIT_DATA_ATTRIBUTES = ImmutableMap.of("data-key", "value2");
    private static final Map<String, Object> AUDIT_PREFIXED_ATTRIBUTES =
            ImmutableMap.of("mandatory-key", "value1", DATA_ATTRIBUTES_PREFIX + "data-key", "value2");

    private HbaseUtility hbaseUtility;

    @Mock
    private ObjectMapper mapper;

    @Before
    public void setUp() {
        hbaseUtility = new HbaseUtility(mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowErrorWhenMapperInstanceIsNull() {
        new HbaseUtility(null);
    }

    @Test(expected = DeserializationException.class)
    public void shouldThrowErrorWhileConvertingRowResultToAuditEntity() throws IOException {

        Map<String, Object> attribues = ImmutableMap.of("key", "value");
        when(mapper.readValue(toBytes("value"), Object.class)).thenThrow(new IOException());

        hbaseUtility.convertResultToAuditEntity(getResultObject(attribues), TABLE_NAME, COLUMN_FAMILY);
    }

    @Test
    public void shouldSuccessfullyConvertRowResultToAuditEntity() {
        AuditEntity expectedAuditEntity = getAuditEntity();

        Map<String, Object> auditAttributes =
                Stream.of(AUDIT_MANDATORY_ATTRIBUTES, ImmutableMap.of(DATA_ATTRIBUTES_KEY_NAME, AUDIT_DATA_ATTRIBUTES))
                        .collect(HashMap::new, Map::putAll, Map::putAll);

        AUDIT_PREFIXED_ATTRIBUTES.forEach((k, v) -> {
            try {
                when(mapper.readValue(toBytes(v), Object.class)).thenReturn(v);
            } catch (IOException e) {
                throw new RuntimeException(e.getMessage(), e);
            }
        });
        when(mapper.convertValue(auditAttributes, AuditEntity.class)).thenReturn(expectedAuditEntity);

        AuditEntity actual = hbaseUtility.convertResultToAuditEntity(getResultObject(AUDIT_PREFIXED_ATTRIBUTES),
                TABLE_NAME, COLUMN_FAMILY);

        assertReflectionEquals(expectedAuditEntity, actual);
    }

    @Test
    public void shouldSuccessfullyConvertAuditEntityToMap() {
        AuditEntity auditEntity = getAuditEntity();

        when(mapper.convertValue(auditEntity, Map.class)).thenReturn(AUDIT_MANDATORY_ATTRIBUTES);

        Map<String, Object> actualAttributes = hbaseUtility.convertAuditEntityToMap(auditEntity);

        assertReflectionEquals(actualAttributes, AUDIT_PREFIXED_ATTRIBUTES);
    }

    @Test(expected = DuplicateAttributeException.class)
    public void shouldThrowErrorWhenDuplicateAttributeKeyFound() {
        AuditEntity auditEntity = getAuditEntity();

        when(mapper.convertValue(auditEntity, Map.class)).thenReturn(AUDIT_PREFIXED_ATTRIBUTES);

        hbaseUtility.convertAuditEntityToMap(auditEntity);
    }

    private AuditEntity getAuditEntity() {

        AuditEntity auditEntity = mock(AuditEntity.class);
        when(auditEntity.getDataAttributes()).thenReturn(AUDIT_DATA_ATTRIBUTES);
        return auditEntity;
    }

    private Result getResultObject(Map<String, Object> attributes) {

        byte[] row = toBytes("row1");
        byte[] family = toBytes(COLUMN_FAMILY);

        Cell[] cells = attributes.entrySet().stream()
                .map(entry -> new KeyValue(row, family, toBytes(entry.getKey()), toBytes(entry.getValue())))
                .toArray(Cell[]::new);

        return Result.create(cells);
    }

    private byte[] toBytes(Object s) {
        return s.toString().getBytes(StandardCharsets.UTF_8);
    }
}
