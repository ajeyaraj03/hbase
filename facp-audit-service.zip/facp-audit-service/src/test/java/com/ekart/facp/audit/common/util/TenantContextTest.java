package com.ekart.facp.audit.common.util;

import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;


/**
 * Created by akshit.agarwal on 02/08/16.
 */
public class TenantContextTest {

    @Test
    public void shouldSatisfyEqualsContract() {
        /*
          We cannot use EqualsVerifier here for unit testing because there are currently no fields in TenantContext,
          Once those come use 'nl.jqno.equalsverifier.EqualsVerifier' for testing.
         */
        TenantContext instance1 = new TenantContext();
        TenantContext instance2 = new TenantContext();

        assertThat(instance1.equals(instance2), is(true));
    }

    @Test
    public void shouldNotSatisfyEqualsContract() {
        /*
          We cannot use EqualsVerifier here for unit testing because there are currently no fields in TenantContext,
          Once those come use 'nl.jqno.equalsverifier.EqualsVerifier' for testing.
         */
        TenantContext instance1 = new TenantContext();
        Object instance2 = new Object();

        assertThat(instance1.equals(instance2), is(false));
    }
}
