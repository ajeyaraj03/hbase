package com.ekart.facp.audit.apis.util;

import org.apache.hadoop.conf.Configuration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.hadoop.hbase.HbaseTemplate;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by akshit.agarwal on 13/07/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class HbaseConnectorTest {
    @Mock
    private HbaseConfigUtil hbaseConfigUtil;

    private HbaseConnector hbaseConnector;

    @Before
    public void setUp() {
        this.hbaseConnector = new HbaseConnector(hbaseConfigUtil);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowIfHbaseConfidUtilInstanceIsNull() {
        new HbaseConnector(null);
    }

    @Test
    public void shouldReturnHbaseTemplateObject() {
        Configuration mockConfig = mock(Configuration.class);
        when(hbaseConfigUtil.getHbaseConfig()).thenReturn(mockConfig);
        HbaseTemplate hbaseTemplate = new HbaseTemplate(mockConfig);
        hbaseTemplate.setAutoFlush(false);
        assertReflectionEquals(hbaseTemplate, hbaseConnector.hbaseTemplate());
    }
}
